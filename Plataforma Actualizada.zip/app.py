import os
import streamlit as st
import json
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
from datetime import datetime
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from config import RISK_LABELS, RISK_COLORS
from utils import apply_riesgo_labels
import io
import zipfile
import base64
import random
import time
import charts 
import streamlit.components.v1 as components
import math
import hashlib  # NEW: For password security
from dotenv import load_dotenv
import analytics
load_dotenv()

from db_queries import (
    fetch_alertas_riesgo_alto,
    fetch_casos_prioritarios,
    fetch_counts_resumen,
    fetch_dashboard_historico,
    fetch_dashboard_profesional,
    fetch_excel_export_bundle,
    fetch_historial_usuario,
    fetch_pdf_resultados_por_usuario,
    fetch_resultados_all,
    fetch_resultados_clustering,
    fetch_riesgo_counts_por_resultado,
    fetch_table_all,
    fetch_ultimas_sesiones_usuario_para_alertas,
    fetch_usuarios_ids_ordered,
    save_result,
    save_survey,
    save_user,
)

from config import (
    AUDIO_FILE_PATH,
    LOADER_SECONDS,
    LOGO_PATH,
    configure_page,
    ensure_directories,
    initialize_database,
)

# ================================================================
# CONFIGURACIÓN GENERAL Y RUTAS DINÁMICAS (FASE 1)
# ================================================================

configure_page()
ensure_directories()
initialize_database()

# ReportLab (opcional)
try:
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas
    REPORTLAB_AVAILABLE = True
except Exception:
    REPORTLAB_AVAILABLE = False

# Scikit-learn (opcional)
try:
    from sklearn.cluster import KMeans
    from sklearn.preprocessing import StandardScaler
    from sklearn.decomposition import PCA
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


# ================================================================
# ROUTER CENTRAL (NUEVO - FASE 1)
# ================================================================

def init_router_state():
    if "route" not in st.session_state:
        st.session_state.route = {
            "rol": "Estudiante",
            "page": None,
            "subpage": None,
        }

def set_route(page, subpage=None):
    st.session_state.route["page"] = page
    st.session_state.route["subpage"] = subpage

def get_route():
    return st.session_state.route


def router():
    route = get_route()
    rol = route["rol"]
    page = route["page"]

    if page is None:
        return

    if rol == "Estudiante":
        estudiante_router(page)

    elif rol == "Docente":
        docente_router(page)

    elif rol == "Psicólogo":
        psicologo_router(page)

    
# ================================================================
# SUB-ROUTERS (ADAPTADOS A TU LÓGICA ACTUAL)
# ================================================================

def estudiante_router(page):
    if page == "registro":
        st.session_state.menu_estudiante = "Registrar encuesta"
    elif page == "historial":
        st.session_state.menu_estudiante = "Ver historial"
    elif page == "resultados":
        st.session_state.menu_estudiante = "Resultados"
    elif page == "info":
        st.session_state.menu_estudiante = "Información"
    elif page == "acerca":
        st.session_state.menu_estudiante = "Acerca"
    else:
        st.session_state.menu_estudiante = None


def docente_router(page):
    if page == "panel":
        st.session_state.menu_docente = "Panel docente"
    elif page == "clustering":
        st.session_state.menu_docente = "Clustering"
    elif page == "dashboard_hist":
        st.session_state.menu_docente = "Dashboard histórico"
    elif page == "dashboard_prof":
        st.session_state.menu_docente = "Dashboard profesional"
    elif page == "alertas":
        st.session_state.menu_docente = "Alertas inteligentes"
    elif page == "export":
        st.session_state.menu_docente = "Exportar datos"
    elif page == "acerca":
        st.session_state.menu_docente = "Acerca"
    else:
        st.session_state.menu_docente = None


def psicologo_router(page):
    if page == "historial":
        st.session_state.menu_psicologo = "Historial individual"
    elif page == "casos":
        st.session_state.menu_psicologo = "Casos prioritarios"
    elif page == "dashboard":
        st.session_state.menu_psicologo = "Dashboard histórico"
    elif page == "acerca":
        st.session_state.menu_psicologo = "Acerca"
    else:
        st.session_state.menu_psicologo = None


# ================================================================
# INICIALIZACIÓN DE ESTADOS DE SESIÓN (SIN CAMBIOS)
# ================================================================

if "landing_done" not in st.session_state:
    st.session_state.landing_done = False
if "loader_shown" not in st.session_state:
    st.session_state.loader_shown = False
if "consentimiento" not in st.session_state:
    st.session_state.consentimiento = False
if "nivel_usuario" not in st.session_state:
    st.session_state.nivel_usuario = "Universidad"
if "clave_docente" not in st.session_state:
    st.session_state.clave_docente = ""
if "uid" not in st.session_state:
    st.session_state.uid = None
if "docente_activo" not in st.session_state:
    st.session_state.docente_activo = False
if "psicologo_activo" not in st.session_state:
    st.session_state.psicologo_activo = False
if "menu_psicologo" not in st.session_state:
    st.session_state.menu_psicologo = "Historial individual"
if "menu_estudiante" not in st.session_state:
    st.session_state.menu_estudiante = "Registrar encuesta"
if "menu_docente" not in st.session_state:
    st.session_state.menu_docente = "Panel docente"
if "logo_clicked" not in st.session_state:
    st.session_state.logo_clicked = False


init_router_state()
# Estado inicial seguro
if "menu_estudiante" not in st.session_state:
    st.session_state.menu_estudiante = "Información"

if "menu_docente" not in st.session_state:
    st.session_state.menu_docente = "Panel docente"

if "menu_psicologo" not in st.session_state:
    st.session_state.menu_psicologo = "Historial individual"

router()



# ================================================================
# CSS PARA OCULTAR ELEMENTOS NO DESEADOS DE STREAMLIT
# ================================================================
st.markdown("""
    <style>
    /* Ocultar elementos de Streamlit */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    .stApp {background: transparent;}
            
    /* SIDEBAR: FORZAR APERTURA Y COLOR OSCURO */
    [data-testid="stSidebar"] {
        transform: none !important;
        visibility: visible !important;
        width: 210px !important;
        margin-left: 0px !important;
        background: #383838 !important;
    }

    [data-testid="stSidebar"] > div:first-child {
        background: #383838 !important;
    }
            
    /* Contenido principal */
    .main {
        padding-left: 210px !important;
        overflow-y: auto !important;
    }
    
    /* Ocultar botones de colapsar */
    [data-testid="stSidebarCollapseButton"],
    [data-testid="collapsedControl"] {
        display: none !important;
    }
            
     /* Eliminar borde rojo de foco en botones */
    .stButton > button:focus {
        border-color: #4fc3f7 !important;
        box-shadow: 0 0 0 2px rgba(79,195,247,0.3) !important;
        outline: none !important;
    }
    .stButton > button:focus:not(:focus-visible) {
        border-color: transparent !important;
        box-shadow: none !important;
    }       
            
    /* Imágenes */
    .stImage img {
        max-width: 100%;
        height: auto;
        pointer-events: none;
    }
            
    /* Ocultar alertas de rerun */
   /* Ocultar solo alertas automáticas de rerun */ 
    .stAlert[data-baseweb="notification"] {
        display: none !important;
    }
            
    /* Sliders — color neutro azul en lugar de rojo */
    .stSlider > div > div > div > div {
        background: #4fc3f7 !important;
    }
    .stSlider > div > div > div {
        background: rgba(79, 195, 247, 0.2) !important;
    }


    /* Ocultar botón START_TRANSITION sin romper funcionalidad */
    div[data-testid="stButton"]:has(button[title="hidden_transition_button"]) {
        position: fixed !important;
        top: -9999px !important;
        left: -9999px !important;
        width: 1px !important;
        height: 1px !important;
        overflow: hidden !important;
        clip: rect(0,0,0,0) !important;
        white-space: nowrap !important;
        pointer-events: none !important;
    }
            
    /* 🔥 FULLSCREEN REAL */
    html, body, #root, .stApp {
        height: 100% !important;
        overflow: hidden !important;
    }

    /* 🔥 Eliminar padding interno */
    .block-container {
        padding: 0 !important;
        margin: 0 !important;
        max-width: 100% !important;
    }

    /* 🔥 FIX adicional (MUY IMPORTANTE) */
    section.main > div {
        padding: 0 !important;
    }

    /* 🔥 IFRAME FULLSCREEN */
    iframe {
        position: fixed !important;
        top: 0;
        left: 0;
        width: 100vw !important;
        height: 100vh !important;
        border: none !important;
        z-index: 9999 !important;
    }

    /* Evitar scroll */
    body {
        overflow: hidden !important;
    }
    
    * {
    box-sizing: border-box;
    }
    </style>
""", unsafe_allow_html=True)

# ================================================================
# UTILIDADES GENERALES
# ================================================================

def img_to_base64(image_path):
    try:
        with open(image_path, "rb") as img_file:
            return base64.b64encode(img_file.read()).decode()
    except:
        return ""

def df_to_csv_bytes(df):
    return df.to_csv(index=False).encode("utf-8")

def export_all_tables_zip_bytes():
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as z:
        for table in ["usuarios", "encuestas", "resultados"]:
            try:
                df = fetch_table_all(table)
                z.writestr(f"{table}.csv", df.to_csv(index=False))
            except Exception:
                z.writestr(f"{table}.csv", "/* Sin datos */")
    buffer.seek(0)
    return buffer.getvalue()

def safe_json_load(s):
    try:
        return json.loads(s)
    except Exception:
        return {}

def safe_float(value, default=0.0):
    """Convierte un valor a flotante de forma segura."""
    try:
        return float(value) 
    except (TypeError, ValueError):
        return default

# ================================================================
# NLP VENEZOLANO — importado desde nlp_analysis.py
# ================================================================
# Toda la lógica de análisis de sentimiento (VADER + ajuste léxico
# venezolano), POMS y Valence-Arousal vive ahora en nlp_analysis.py.
# Se importa aquí para no tener que reescribir cada llamada existente
# en el resto de app.py.
from nlp_analysis import (
    EMOCIONES_VE,
    PALABRAS_NEGATIVAS,
    POMS_ITEMS,
    analyze_text_advanced,
    get_emociones_texto,
    score_poms,
    normalize_va,
    classify_profile,
)

# ================================================================
# FASE 1 — Sistema de encuestas por nivel
# ================================================================

def get_questions_by_level(nivel: str):
    """
    Estructura de preguntas exclusiva para el nivel universitario.
    """
    if nivel == "Universidad":  # UNIVERSIDAD
        return [
        {"id": "estres", "tipo": "likert", "texto": "Nivel de estrés académico"},
        {"id": "fatiga", "tipo": "likert", "texto": "Fatiga mental reciente"},
        {"id": "presion", "tipo": "likert", "texto": "Autoexigencia y perfeccionismo"},
        {"id": "burnout", "tipo": "likert", "texto": "Sensación de agotamiento (burnout)"},
        {"id": "suenio", "tipo": "likert", "texto": "Calidad del sueño"},
        {"id": "social", "tipo": "likert", "texto": "Conexión social / apoyo"},
        {"id": "poms_tension", "tipo": "likert", "texto": "Tensión (POMS)"},
        {"id": "poms_depresion", "tipo": "likert", "texto": "Depresión (POMS)"},
        {"id": "poms_fatiga", "tipo": "likert", "texto": "Fatiga (POMS)"},
        {"id": "poms_vigor", "tipo": "likert", "texto": "Vigor (POMS, invertido)"},
        {"id": "valence_raw", "tipo": "likert_9", "texto": "¿Cómo describes tu estado emocional ahora mismo? (1=muy negativo, 9=muy positivo)"},
        {"id": "nd_atencion", "tipo": "likert", "texto": "¿Con qué frecuencia pierdes la concentración en tareas que requieren esfuerzo sostenido?"},
        {"id": "nd_sensorial", "tipo": "likert", "texto": "¿La sensibilidad a estímulos sensoriales (ruido, luz, texturas) interfiere con tu desempeño?"},
        {"id": "nd_inicio", "tipo": "likert", "texto": "¿Experimentas dificultad para iniciar actividades a pesar de tener la intención de hacerlas?"},
        {"id": "nd_olvidos", "tipo": "likert", "texto": "¿Presentas olvidos frecuentes que afectan tu organización y rendimiento académico?"},
        {"id": "nd_rutinas", "tipo": "likert", "texto": "¿Dependes de rutinas muy específicas y te afecta significativamente cuando se alteran?"},
        {"id": "nd_social", "tipo": "likert", "texto": "¿Encuentras desafiante interpretar señales sociales o mantener interacciones convencionales?"},
        {"id": "arousal_raw", "tipo": "likert_9", "texto": "¿Cuál es tu nivel de activación o energía ahora mismo? (1=muy tranquilo, 9=muy activado)"},
        {"id": "texto", "tipo": "texto", "texto": "Describe cómo te sientes (opcional)"}
    ]

def render_questions_by_level(questions):
    respuestas = {}

    preguntas_normales = []
    pregunta_texto = None

    # Separar preguntas
    for q in questions:
        if q["tipo"] == "texto":
            pregunta_texto = q
        else:
            preguntas_normales.append(q)

    # 1. Renderizar preguntas normales primero
    for q in preguntas_normales:

        if q["tipo"] == "likert":
            respuestas[q["id"]] = st.slider(q["texto"], 1, 5, 3)

        elif q["tipo"] == "carita":
            respuestas[q["id"]] = st.select_slider(
                q["texto"],
                options=q["opciones"],
                value=q["opciones"][2]
            )

        elif q["tipo"] == "likert_9":
            respuestas[q["id"]] = st.slider(q["texto"], 1, 9, 5)

    # 2. TEXTO SIEMPRE AL FINAL
    if pregunta_texto:
        respuestas[pregunta_texto["id"]] = st.text_area(
            pregunta_texto["texto"],
            height=120
        )

    return respuestas

def process_results_by_level(nivel, respuestas, analisis_texto):
    polarity, subjectivity, neg_count = analisis_texto
    q = respuestas

    # Normalizar base a 0-1
    estres_n  = (q["estres"] - 1) / 4
    fatiga_n  = (q["fatiga"] - 1) / 4
    presion_n = (q["presion"] - 1) / 4
    burnout_n = (q["burnout"] - 1) / 4
    suenio_n  = (5 - q["suenio"]) / 4    # invertido
    social_n  = (5 - q["social"]) / 4    # invertido

    base_norm = (estres_n + fatiga_n + presion_n + burnout_n + suenio_n + social_n) / 6

    # Normalizar POMS a 0-1
    tension_n    = (q["poms_tension"] - 1) / 4
    depresion_n  = (q["poms_depresion"] - 1) / 4
    fatiga_p_n   = (q["poms_fatiga"] - 1) / 4
    vigor_n      = (5 - q["poms_vigor"]) / 4   # invertido

    poms_norm = (tension_n + depresion_n + fatiga_p_n + vigor_n) / 4

    # Penalización texto
    texto_penalty = (neg_count * 0.03) + ((1 - polarity) * 0.03)

    # Puntaje final 0-1 (base 70%, POMS 30%)
    puntaje = (base_norm * 0.70) + (poms_norm * 0.30) + texto_penalty

    # Garantizar que el puntaje permanezca dentro del rango 0..1
    puntaje = max(0.0, min(1.0, puntaje))

    # VA real
    valence_raw = respuestas.get("valence_raw", 5)
    arousal_raw = respuestas.get("arousal_raw", 5)
    valence_calc, arousal_calc = normalize_va(valence_raw, arousal_raw)

    nd_items = [
        respuestas.get("nd_atencion", 3),
        respuestas.get("nd_sensorial", 3),
        respuestas.get("nd_inicio", 3),
        respuestas.get("nd_olvidos", 3),
        respuestas.get("nd_rutinas", 3),
        respuestas.get("nd_social", 3),
    ]
    nd_score = (sum(nd_items) / len(nd_items) - 1) / 4

    # Clasificación final (escala 0-1)
    if puntaje >= 0.65:
        riesgo = "Alto"
    elif puntaje >= 0.40:
        riesgo = "Medio"
    else:
        riesgo = "Bajo"

    return puntaje, riesgo, valence_calc, arousal_calc, nd_score

# ================================================================
# LANDING PAGE
# ================================================================

def show_landing_page(logo_base64):
    # 1. Carga invisible del audio
    st.audio("static/clic.wav", format='audio/wav', start_time=0) 
    
    # 2. Estilos generales (Ocultar elementos nativos de Streamlit)
    st.markdown("""
    <style>
    /* Ocultar elementos de Streamlit (menú, footer, header) */
    #MainMenu, footer, header { visibility: hidden; }
    .stApp {background: transparent;}
            
    /* --------------------------------------------------------------------- */
    /* SOLUCIÓN 1: OCULTAR REPRODUCTOR DE AUDIO (PERO FUNCIONAL) */
    /* --------------------------------------------------------------------- */
    [data-testid="stAudio"] {
        display: none !important; /* Esto lo oculta de la vista sin quitar la funcionalidad */
    }

    /* --------------------------------------------------------------------- */
    /* SOLUCIÓN 2: SIDEBAR (VISIBILIDAD Y COLOR OSCURO DEFINITIVO) */
    /* --------------------------------------------------------------------- */
    
    /* Contenedor Externo: Fuerza visibilidad, posición, y aplica el color de fondo */
    [data-testid="stSidebar"] {
        /* Reglas de visibilidad y posición forzada */
        transform: none !important; 
        visibility: visible !important; 
        width: 210px !important; 
        margin-left: 0px !important; 
        
        /* 💡 CORRECCIÓN DE COLOR: Aplica color oscuro var(--bg-2) */
        background-color: var(--bg-2) !important;
        background: var(--bg-2) !important;
    } 
            
    /* Contenedor Interno: Sobreescribe el fondo blanco que puede venir de load.css */
    [data-testid="stSidebar"] > div:first-child {
        background: var(--bg-2) !important;
    }
    
    /* Contenido Principal: Crea el espacio para la sidebar y oculta scroll general */
    .main {
        padding-left: 210px !important; 
        overflow-y: hidden !important; 
    }

    /* Oculta todos los botones de colapsar */
    [data-testid="stSidebarCollapseButton"], 
    [data-testid="collapsedControl"] {
        display: none !important;
    }
            
    /* --------------------------------------------------------------------- */
    /* REGLAS ESTÉTICAS ADICIONALES */
    /* --------------------------------------------------------------------- */
    
    /* Ocultar el botón de fullscreen de la imagen y prevenir zoom */
    .stImage img {
        max-width: 100%;
        height: auto;
        pointer-events: none;
    }
            
    /* Ocultar mensajes de st.rerun() */
    .stAlert {
        display: none !important;
    }
    </style>
""", unsafe_allow_html=True)
    
    # 3. Contenido de la landing page dentro de un IFRAME aislado (Full Screen)
    html_content = f"""
        <html>
        <head>
            <style>
            /* Estilos para la toma de control de pantalla completa (100vw, 100vh) */
            html, body {{
                margin: 0;
                padding: 0;
                overflow: hidden;
                height: 100%
            }}
            .landing-container {{
                position: fixed; 
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                background: linear-gradient(135deg, #0a2a43 0%, #0e4d92 50%, #1976d2 100%);
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                color: white;
                text-align: center;
                z-index: 9999;
                padding: 2rem;
            }}
            .logo-container {{
                margin-bottom: 2rem;
                cursor: pointer;
                transition: all 0.5s ease;
            }}
            .logo-img {{
                width: clamp(140px, 18vw, 230px);
                height: auto;
                /* Efecto de brillo detrás */
                filter: drop-shadow(0 0 20px rgba(79, 195, 247, 0.8)); 
                margin-bottom: 1.5rem;
                transition: all 0.3s ease;
                animation: logoGlow 3s ease-in-out infinite;
            }}
            .logo-img:hover {{
                transform: scale(1.05);
                filter: drop-shadow(0 0 30px rgba(79, 195, 247, 1));
            }}
            .logo-img:active {{
                transform: scale(0.95);
            }}
            .title {{
                font-size: clamp(1.8rem, 3vw, 2.5rem);
                font-weight: 700;
                margin-bottom: 1rem;
                text-shadow: 0 0 10px rgba(255, 255, 255, 0.5);
                animation: fadeInUp 1s ease-out;
            }}
            .subtitle {{
                font-size: clamp(0.9rem, 1.2vw, 1.2rem);
                margin-bottom: 3rem;
                opacity: 0.9;
                max-width: 600px;
                animation: fadeInUp 1s ease-out 0.3s both;
            }}
            /* Partículas y Animaciones (Se mantienen) */
            .particle {{
                position: absolute;
                background: rgba(255, 255, 255, 0.3);
                border-radius: 50%;
                animation: float 6s ease-in-out infinite;
            }}
            .particle:nth-child(1) {{ width: 8px; height: 8px; top: 20%; left: 10%; animation-delay: 0s; }}
            .particle:nth-child(2) {{ width: 12px; height: 12px; top: 60%; left: 80%; animation-delay: 1s; }}
            .particle:nth-child(3) {{ width: 6px; height: 6px; top: 80%; left: 20%; animation-delay: 2s; }}
            .particle:nth-child(4) {{ width: 10px; height: 10px; top: 30%; left: 70%; animation-delay: 3s; }}
            .particle:nth-child(5) {{ width: 7px; height: 7px; top: 70%; left: 40%; animation-delay: 4s; }}
            
            @keyframes logoGlow {{
                0%, 100% {{ filter: drop-shadow(0 0 20px rgba(79, 195, 247, 0.8)); }}
                50% {{ filter: drop-shadow(0 0 30px rgba(79, 195, 247, 1)) drop-shadow(0 0 40px rgba(79, 195, 247, 0.4)); }}
            }}
            @keyframes fadeInUp {{
                from {{ opacity: 0; transform: translateY(30px); }}
                to {{ opacity: 1; transform: translateY(0); }}
            }}
            @keyframes float {{
                0%, 100% {{ transform: translateY(0px) rotate(0deg); }}
                50% {{ transform: translateY(-20px) rotate(180deg); }}
            }}
            @keyframes pulse {{
                0% {{ transform: scale(1); }}
                50% {{ transform: scale(1.1); }}
                100% {{ transform: scale(1); }}
            }}
            @keyframes fadeOut {{
                to {{ opacity: 0; transform: scale(0.95); }}
            }}
            </style>
        </head>
        <body>
            <div class="landing-container">
                <div class="particle"></div>
                <div class="particle"></div>
                <div class="particle"></div>
                <div class="particle"></div>
                <div class="particle"></div>
                
                <div class="logo-container" id="logoClickable">
                    <img class="logo-img" src="data:image/png;base64,{logo_base64}" alt="Logo Plataforma" onclick="handleLogoClick()">
                </div>
                <div class="title">Plataforma Preventiva de Detección Emocional</div>
                <div class="subtitle">Haz clic en el cerebro para iniciar la evaluación</div>
            </div>
            
            <script>
            function handleLogoClick() {{
                // Buscamos el elemento de audio en el documento padre (Streamlit)
                const audioPlayer = window.parent.document.querySelector('audio');
                
                if (audioPlayer) {{
                    audioPlayer.currentTime = 0; 
                    audioPlayer.play().catch(e => console.error('Error reproduciendo audio:', e));
                }}
                
                const logo = document.querySelector('.logo-img');
                const container = document.querySelector('.landing-container');
                
                logo.style.animation = 'pulse 0.5s ease-out';
                container.style.animation = 'fadeOut 0.8s ease-out forwards';
                
                // Enviar evento a Streamlit para pasar a la siguiente pantalla (loading)
                setTimeout(() => {{
                    const buttons = window.parent.document.querySelectorAll('button');
                    let found = false;
                    for (let btn of buttons) {{
                        if (btn.innerText.trim() === 'START_TRANSITION') {{
                            btn.style.pointerEvents = 'auto';
                            btn.click();
                            found = true;
                            break;
                        }}
                    }}
                     if (!found) {{
                        console.warn('Botón START_TRANSITION no encontrado');
                    }}
                }}, 1200);
            }}
            </script>
        </body>
        </html>
    """
    
    # 4. Renderizar el IFRAME
    components.html(
        html_content,
        height=0,
        scrolling=False
    )

    # 5. Botón de Transición Invisible (Activado por JS)
    st.button(
        "START_TRANSITION", 
        on_click=lambda: setattr(st.session_state, 'landing_done', True),
        key="transition_btn",
        help="hidden_transition_button"  
    )

# 6. Hide Transition Button ONLY (Ultimate Solution)
st.markdown("""
<style>
/* El botón de transición usa key="transition_btn" y title="hidden_transition_button" */
/* Apuntamos al botón dentro de su contenedor de Streamlit (data-testid="stButton") */
div[data-testid="stButton"] button[title="hidden_transition_button"] {
    /* Ocultamiento agresivo */
    display: none !important;
    visibility: hidden !important;
    height: 0 !important;
    width: 0 !important;
    position: absolute !important;
    top: -9999px !important;
    left: -9999px !important;
    opacity: 0 !important;
    pointer-events: none !important;
    z-index: -9999 !important;
}

/* Aseguramos que los demás botones NO se vean afectados */
.stButton button:not([title="hidden_transition_button"]) {
    visibility: visible !important;
    display: inline-block !important;
}
</style>
""", unsafe_allow_html=True)

# ================================================================
# LOADER MEJORADO
# ================================================================

FRASES_LOADER = [
    "El cerebro no distingue entre imaginación y realidad.",
    "Tu historia no define tu destino.",
    "Conocerse a sí mismo es el principio de toda sabiduría. Aristóteles",
    "La mente es como un paracaídas: solo funciona si se abre.",
    "Todo aprendizaje tiene una base emocional. Platón",
    "La resiliencia es la capacidad de sanar en la adversidad.",
    "Sigue a tu corazón, pero lleva contigo a tu cerebro. Alfred Adler",
    "Lo que niegas te somete; lo que aceptas te transforma. C.G. Jung",
    "El equilibrio es la fuerza de tolerar emociones dolorosas. Melanie Klein",
    "La atención es la llave del cambio.",
]

def show_loading_screen(logo_base64: str, frase: str, seconds: int = 3):
    """Loader mejorado que ocupa toda la pantalla como la landing"""
    html = f"""
<!DOCTYPE html>
<html>
<head>
<style>
  html,body {{
    height: 100%;
    margin: 0;
    padding: 0;
    overflow: hidden;
  }}
  .loader-wrap {{
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    background: linear-gradient(135deg, #2E6FF2 0%, #7B5DFA 100%);
    z-index: 9999;
    animation: fadeIn 0.5s ease-out;
  }}
  .content {{
    max-width: 500px;
    padding: 2rem;
  }}
  .logo-img {{
    width: clamp(140px, 18vw, 230px);
    height: auto;
    margin-bottom: 2rem;
    display: block;
    margin-left: auto;
    margin-right: auto;
    border-radius: 10px;
    animation: logoPulse 2s ease-in-out infinite;
  }}
  .loader-text {{
    font-size: clamp(1.8rem, 3vw, 2.5rem);
    color: white;
    margin-bottom: 2rem;
    font-weight: 500;
    animation: fadeInUp 0.8s ease-out;
  }}
  .progress-container {{
    width: 100%;
    max-width: 400px;
    height: 8px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 10px;
    margin: 0 auto 1rem auto;
    overflow: hidden;
  }}
  .progress-bar {{
    width: 0%;
    height: 100%;
    background: linear-gradient(90deg, #FFD93D, #FF6B6B);
    border-radius: 10px;
    transition: width 0.3s ease;
  }}
  .loader-subtext {{
    font-size: clamp(0.9rem, 1.2vw, 1.2rem);
    color: rgba(255, 255, 255, 0.8);
    animation: fadeInUp 1s ease-out;
  }}
  
  @keyframes fadeIn {{
    from {{ opacity: 0; }}
    to {{ opacity: 1; }}
  }}
  
  @keyframes fadeInUp {{
    from {{ 
        opacity: 0; 
        transform: translateY(20px); 
    }}
    to {{ 
        opacity: 1; 
        transform: translateY(0); 
    }}
  }}
  
  @keyframes logoPulse {{
    0%, 100% {{ transform: scale(1); opacity: 0.9; }}
    50% {{ transform: scale(1.05); opacity: 1; }}
  }}
</style>
</head>
<body>
    <div class="loader-wrap">
        <div class="content">
            <img class="logo-img" src="data:image/png;base64,{logo_base64}" />
            <div class="loader-text">{frase}</div>
            <div class="progress-container">
                <div class="progress-bar" id="loader-progress"></div>
            </div>
            <div class="loader-subtext">Inicializando plataforma...</div>
        </div>
    </div>
    
    <script>
        let duration = {seconds};
        let progress = document.getElementById("loader-progress");
        let startTime = Date.now();
        
        function updateProgress() {{
            let elapsed = (Date.now() - startTime) / 1000;
            let percentage = Math.min((elapsed / duration) * 100, 100);
            progress.style.width = percentage + "%";
            
            if (percentage < 100) {{
                requestAnimationFrame(updateProgress);
            }}
        }}
        updateProgress();
    </script>
</body>
</html>
"""
    components.html(
    html,
    height=0,
    scrolling=False
)

# ================================================================
# FUNCIÓN DE LOGOUT
# ================================================================

def logout():
    """Función de logout mejorada - Limpia estados de Docente y Psicólogo"""
    
    # 1. Limpiar estados de autenticación de ambos roles
    auth_keys = [
        'docente_activo', 'docente', 'logged_in_user_id',
        'psicologo_activo', 'psicologo'
    ]
    for key in auth_keys:
        if key in st.session_state:
            del st.session_state[key]
            
    # 2. Forzar que el radio button y el router vuelvan a "Estudiante"
    if 'rol_seleccionado' in st.session_state:
        st.session_state.rol_seleccionado = "Estudiante"
        
    if 'route' in st.session_state and isinstance(st.session_state.route, dict):
        st.session_state.route["rol"] = "Estudiante"

    # 3. Mantener estados esenciales
    essential_keys = ['landing_done', 'loader_shown', 'consentimiento', 'nivel_usuario', 'uid']
    for key in essential_keys:
        if key not in st.session_state:
            if key == 'consentimiento':
                st.session_state[key] = False
            elif key == 'nivel_usuario':
                st.session_state[key] = "Universidad"
    
    # 4. Activar bandera para recargar la interfaz de forma segura
    st.session_state.needs_rerun = True



def md_to_html(text: str) -> str:
    """Convierte markdown básico (**negrita**) a HTML para usar dentro de divs."""
    import re
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', text)
    text = text.replace('\n\n', '<br><br>').replace('\n', '<br>')
    return text

# ================================================================
# FUNCIÓN AUXILIAR DE REPORTE INDIVIDUAL (SHOW SINGLE REPORT)
# ================================================================

def show_single_report(riesgo, perfil, resultado=None):
    """Muestra un reporte profesional basado en riesgo, perfil y detalle técnico"""
    st.title("✅ Reporte de Análisis Emocional")
    
    # ================================================================
    # 1. DEFINIR Y VALIDAR LOS DATOS
    # ================================================================
    datos = resultado if isinstance(resultado, dict) else {}
    
    # ================================================================
    # 2. EXTRAER TODAS LAS MÉTRICAS CON VALORES POR DEFECTO
    # ================================================================
    valence = datos.get("va", {}).get("valence", 0.0)
    arousal = datos.get("va", {}).get("arousal", 0.5)

    polarity = datos.get("emocional", {}).get("polarity", 0.0)
    subjectivity = datos.get("emocional", {}).get("subjectivity", 0.0)
    neg_words = datos.get("emocional", {}).get("neg_words", 0)

    poms_tension = datos.get("poms", {}).get("tension", 0.0)
    poms_fatigue = datos.get("poms", {}).get("fatigue", 0.0)

    promedio = datos.get("puntaje", 0.0)

    texto_snippet = datos.get("texto", "")
    
    # Historial para motor de analytics (obtenido del dict o fallback simulado)

    historial_riesgo = [promedio]   

    # ================================================================
    # 3. CONFIGURACIÓN VISUAL PROFESIONAL
    # ================================================================
    perfil_mapeado = {
        "Estrés": "Ansioso/Tenso",
        "Resiliente": "Resiliente",
        "Fatigado": "Fatigado", 
        "Inestable emocional": "Inestable emocional",
        "Riesgo neuro-afectivo": "Riesgo neuro-afectivo",
        "Perfil mixto": "Perfil mixto"
    }.get(perfil, perfil)
    
    config_riesgo = {
        "Alto": {"color": "#ff4444", "emoji": "🔴", "color_name": "rojo"},
        "Medio": {"color": "#ffaa44", "emoji": "🟠", "color_name": "naranja"},
        "Bajo": {"color": "#44cc44", "emoji": "🟢", "color_name": "verde"}
    }

    emojis_perfil = {
        "Resiliente": "🛡️",
        "Ansioso/Tenso": "😰", 
        "Fatigado": "😴",
        "Inestable emocional": "🎭",
        "Riesgo neuro-afectivo": "🧠",
        "Perfil mixto": "🌈"
    }
    
    emoji_perfil = emojis_perfil.get(perfil_mapeado, "📊")
    
    # Normalizar riesgo
    riesgo_normalizado = riesgo.lower() if isinstance(riesgo, str) else "medio"

    if "alto" in riesgo_normalizado:
        riesgo_key = "Alto"
    elif "medio" in riesgo_normalizado:
        riesgo_key = "Medio"
    else:
        riesgo_key = "Bajo"

    riesgo_config = config_riesgo.get(riesgo_key, {"color": "#666666", "emoji": "⚪", "color_name": "gris"})

    # ================================================================
    # 4. ENCABEZADO Y TRAYECTORIA (CONEXIÓN 1: ANALYTICS)
    # ================================================================
    st.markdown(f"""
    ### {riesgo_config['emoji']} **Nivel de Riesgo:** <span style='color:{riesgo_config['color']}; font-weight:bold;'>{riesgo_key.upper()}</span>
    ### {emoji_perfil} **Perfil Emocional:** {perfil_mapeado}
    """, unsafe_allow_html=True)
    
    # --- CONEXIÓN CON ANALYTICS.PY (CÁLCULOS DE TRAYECTORIA) ---
    trend_info = analytics.analyze_risk_trend(historial_riesgo)
    is_deteriorating = analytics.detect_progressive_deterioration(historial_riesgo)
    abrupt_info = analytics.detect_abrupt_change(historial_riesgo)
    priority_score = analytics.calculate_priority_score(promedio, historial_riesgo)
    stability_index = analytics.calculate_stability_index(historial_riesgo)
    
    # Renderizado de métricas evolutivas
    c_tr1, c_tr2, c_tr3, c_tr4 = st.columns(4)
    with c_tr1:
        st.metric("Prioridad Institucional", f"{priority_score}/100")
    with c_tr2:
        st.metric("Tendencia Histórica", trend_info["trend"], delta=f"{trend_info['delta']}")
    with c_tr3:
        st.metric("Índice Estabilidad", f"{stability_index}%")
    with c_tr4:
        st.metric("Alerta Deterioro", "SÍ ⚠️" if is_deteriorating or abrupt_info["abrupt"] else "NO")

    st.markdown("---")

    # ================================================================
    # 5. PERFIL EMOCIONAL VISUAL
    # ================================================================
    st.subheader("🎯 Perfil Emocional Visual")

    def clamp(v):
        return max(v, 0.01)

    valores = [
        clamp(min(promedio, 1.0)),
        clamp(min(poms_fatigue, 1.0)),
        clamp(min(poms_tension, 1.0)),
        clamp(min(arousal, 1.0)),
        clamp((valence + 1) / 2)
    ]

    fig_radar, color_linea = charts.crear_radar_poms(valores, riesgo_key)

    col_radar, col_legend = st.columns([2, 1])
    with col_radar:
        st.plotly_chart(fig_radar, use_container_width=True)
    with col_legend:
        st.markdown("<br><br>", unsafe_allow_html=True)
        st.markdown(f"""
        <div style='padding:15px;border-radius:8px;background:rgba(255,255,255,0.05);'>
            <p style='color:#aaaaaa;font-size:0.85em;margin:0 0 10px 0;'><strong>Cómo leer el radar:</strong></p>
            <p style='color:#cccccc;font-size:0.82em;margin:0;'>
                Área <span style='color:{color_linea};'>coloreada</span>: tu perfil.<br><br>
                Polígono pequeño = menor malestar.
            </p>
        </div>
        """, unsafe_allow_html=True)

    # ================================================================
    # 6. ANÁLISIS PSICOLÓGICO Y MOTOR DE RECOMENDACIONES (CONEXIÓN 2: ANALYTICS)
    # ================================================================
    st.subheader("🔬 Análisis Psicológico y Neurocientífico")
    
    # Explicación automatizada del riesgo basada en factores
    reasons = analytics.explain_risk(
        stress=poms_tension * 5,  # Escala 0-5
        fatigue=poms_fatigue * 5,
        polarity=polarity,
        trend=trend_info["trend"]
    )
    
    if reasons:
        st.markdown("**Factores Determinantes Detectados por el Motor:**")
        for reason in reasons:
            st.markdown(f"- ⚠️ {reason}")

    # Mapeo tradicional de recomendaciones estáticas
    recomendaciones_profesionales = {
        "Resiliente": {
            "alto": {
                "titulo": "🛡️ Resiliencia bajo Presión Extrema",
                "analisis": f"**Análisis Psicológico:** Aunque tu perfil muestra capacidad de adaptación (Resiliente), el nivel de riesgo ALTO ({promedio:.2f}) indica que estás enfrentando desafíos que superan temporalmente tus recursos de afrontamiento habituales.\n\n**Bases Neurocientíficas:** La resiliencia depende de la conectividad prefrontal-ínsula. Bajo estrés crónico, esta conectividad puede verse comprometida, afectando la regulación emocional.",
                "recomendaciones": [
                    "💡 **Intervención Inmediata:** Programa descansos obligatorios cada 90 minutos",
                    "🧠 **Neuroplasticidad Dirigida:** 15 minutos diarios de aprendizaje novedoso",
                    "🫀 **Coherencia Cardíaca:** Técnica 6-6-6 (6 segundos inhalar, 6 exhalar)",
                    "📊 **Monitoreo:** Registra patrones de estrés para identificar triggers"
                ]
            },
            "medio": {
                "titulo": "🛡️ Resiliencia con Desafíos Moderados",
                "analisis": f"Análisis Psicológico: Perfil Resiliente con riesgo MEDIO. Mantienes buenas estrategias de afrontamiento, pero algunos factores están desafiando tu equilibrio habitual.\n\n**Bases Neurocientíficas:** La corteza prefrontal y la ínsula mantienen buena integración, con signos de sobrecarga temporal.",
                "recomendaciones": [
                    "🧘 Mindfulness Preventivo: 10 minutos diarios de atención plena",
                    "🏃 Ejercicio Aeróbico: 30 minutos, 3 veces por semana",
                    "🌙 Higiene de Sueño: Rutina consistente, sin pantallas 1h antes",
                    "🤝 Conexión Social: Mantén contactos de apoyo regularmente"
                ]
            },
            "bajo": {
                "titulo": "🛡️ Resiliencia Óptima Funcional",
                "analisis": f"Análisis Psicológico: ¡Excelente! Tu perfil Resiliente muestra capacidad de adaptación y recuperación en niveles óptimos.",
                "recomendaciones": [
                    "✅ Mantenimiento: Continúa con tus prácticas actuales",
                    "🌟 Variedad Experiencial: Incorpora nuevos aprendizajes",
                    "🌐 Conexión Social Profunda: Fortalece redes significativas"
                ]
            }
        },
        "Ansioso/Tenso": {
            "alto": {
                "titulo": "😰 Ansiedad Clínicamente Significativa",
                "analisis": f"Análisis Psicológico: Niveles elevados de tensión ({poms_tension:.2f}/1.0) y activación ({arousal:.2f}/1.0). El sistema nervioso simpático muestra activación sostenida.",
                "recomendaciones": [
                    "🆘 Intervención Prioritaria: Consulta profesional de salud mental",
                    "🌬️ Respiración 4-7-8: 4s inhalar, 7s retener, 8s exhalar",
                    "🌍 Grounding 5-4-3-2-1: 5 cosas que ves, 4 que tocas, 3 que oyes, 2 que hueles, 1 que pruebas"
                ]
            },
            "medio": {
                "titulo": "😰 Ansiedad Moderada Funcional",
                "analisis": f"Análisis Psicológico: Tensión psicológica presente dentro de rangos manejables.",
                "recomendaciones": [
                    "🫀 Coherencia Cardíaca: 6 respiraciones/minuto durante 5 minutos",
                    "🚶 Ejercicio Moderado: Caminata diaria de 30 minutos"
                ]
            },
            "bajo": {
                "titulo": "😰 Ansiedad Adaptativa Leve",
                "analisis": "Análisis Psicológico: Preocupación y tensión dentro de rangos normales adaptativos.",
                "recomendaciones": ["🛡️ Prevención: Mantén técnicas de relajación como hábito"]
            }
        },
        "Fatigado": {
            "alto": {
                "titulo": "😴 Fatiga Crónica Severa",
                "analisis": f"Análisis Psicológico: Agotamiento significativo (fatiga POMS: {poms_fatigue:.2f}/1.0). Depleción de recursos cognitivos.",
                "recomendaciones": ["💤 Prioridad Absoluta: 7-9 horas sueño ininterrumpido"]
            },
            "medio": {
                "titulo": "😴 Fatiga Mental Moderada",
                "analisis": "Análisis Psicológico: Cansancio mental presente con recursos cognitivos disminuidos.",
                "recomendaciones": ["😴 Siestas Estratégicas: 20-30 minutos máximo"]
            },
            "bajo": {
                "titulo": "😴 Fatiga Leve Recuperable",
                "analisis": "Análisis Psicológico: Cansancio esperable dada la actividad reciente.",
                "recomendaciones": ["⏸️ Descanso Preventivo: No esperes al agotamiento total"]
            }
        }
    }
    
    # Fallback genérico para perfiles no mapeados explícitamente arriba
    base_rec = recomendaciones_profesionales.get(perfil_mapeado, {}).get(
        riesgo_key.lower(), 
        {
            "titulo": f"📊 Evaluación de Perfil: {perfil_mapeado}",
            "analisis": f"El análisis integrativo presenta un estado afectivo con nivel de riesgo {riesgo_key}.",
            "recomendaciones": ["Dar seguimiento continuo a través de la plataforma."]
        }
    )

    st.markdown(f"### {base_rec['titulo']}")
    
    color_border = ries_bg = config_riesgo[riesgo_key]["color"]
    contenido_html = f"""
    <div style='background:rgba(255,255,255,0.03);border-left:4px solid {color_border};
    padding:20px;border-radius:10px;margin:15px 0;color:inherit;'>
    <p><strong>📋 ANÁLISIS DETALLADO:</strong></p>
    <p>{base_rec['analisis']}</p>
    <hr>
    <p><strong>🎯 RECOMENDACIONES ESPECÍFICAS:</strong></p>
    <ul>{"".join(f"<li>{r}</li>" for r in base_rec['recomendaciones'])}</ul>
    </div>
    """
    st.markdown(contenido_html, unsafe_allow_html=True)

    # --- RECOMENDACIONES DINÁMICAS BASADAS EN MOTOR DE ANALYTICS ---
    neurodiv = datos.get("cognitivo", {})
    nd_score_rep = neurodiv.get("nd_score", 0.0) * 100  # Convertir a escala de 0 a 100

    auto_recs = analytics.generate_recommendations(
        risk_level=riesgo_key,
        cognitive_score=nd_score_rep,
        trend_data={"deterioration": is_deteriorating}
    )

    if auto_recs:
        st.markdown("#### 🤖 Sugerencias del Motor Analítico")
        for rec in auto_recs:
            st.info(f"👉 {rec}")

    st.markdown("---")
    
    # ================================================================
    # 7. PANEL DE MÉTRICAS TÉCNICAS
    # ================================================================
    st.subheader("📊 Panel de Métricas Técnicas")
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric(
            label="Puntaje General", 
            value=f"{promedio:.2f}",
            delta="ALTO" if promedio >= 0.65 else "MODERADO" if promedio >= 0.35 else "BAJO",
            delta_color="inverse" if promedio >= 0.65 else "normal"
        )
    with col2:
        st.metric(
            label="Valence (Placer)", 
            value=f"{valence:.2f}",
            delta="POSITIVO" if valence > 0.2 else "NEGATIVO" if valence < -0.2 else "NEUTRAL",
            delta_color="normal" if valence > 0.2 else "inverse" if valence < -0.2 else "off"
        )
    with col3:
        st.metric(
            label="Arousal (Activación)", 
            value=f"{arousal:.2f}",
            delta="ALTA" if arousal > 0.7 else "BAJA" if arousal < 0.3 else "MODERADA"
        )
    
    col4, col5, col6 = st.columns(3)
    with col4:
        st.metric(
            label="Palabras Negativas", 
            value=neg_words,
            delta="ELEVADO" if neg_words >= 3 else "MODERADO" if neg_words >= 1 else "BAJO",
            delta_color="inverse" if neg_words >= 3 else "off"
        )
    with col5:
        st.metric(
            label="Polaridad Textual", 
            value=f"{polarity:.2f}",
            delta="POSITIVA" if polarity > 0.1 else "NEGATIVA" if polarity < -0.1 else "NEUTRAL"
        )
    with col6:
        st.metric(
            label="Subjetividad", 
            value=f"{subjectivity:.2f}",
            delta="ALTA" if subjectivity > 0.7 else "BAJA" if subjectivity < 0.3 else "MEDIA"
        )

    # ================================================================
    # 8. INDICADORES DE NEURODIVERSIDAD (CONEXIÓN 3: ANALYTICS)
    # ================================================================
    atencion_rep = neurodiv.get("atencion", 0.5)
    sensibilidad_rep = neurodiv.get("sensibilidad", 0.5)

    if neurodiv:
        st.markdown("---")
        st.subheader("🧩 Indicadores de Procesamiento Cognitivo")
        st.caption("Estos indicadores son orientativos y NO constituyen diagnóstico de neurodiversidad.")

        col_n1, col_n2, col_n3 = st.columns(3)
        with col_n1:
            st.metric(
                label="Índice Global ND",
                value=f"{neurodiv.get('nd_score', 0.5):.2f}",
                delta="ELEVADO" if neurodiv.get('nd_score', 0.5) >= 0.6 else "MODERADO" if neurodiv.get('nd_score', 0.5) >= 0.4 else "BAJO",
                delta_color="inverse" if neurodiv.get('nd_score', 0.5) >= 0.6 else "off"
            )
        with col_n2:
            st.metric(
                label="Atención",
                value=f"{atencion_rep:.2f}",
                delta="DIFICULTAD" if atencion_rep >= 0.6 else "MODERADA" if atencion_rep >= 0.4 else "ADECUADA",
                delta_color="inverse" if atencion_rep >= 0.6 else "off"
            )
        with col_n3:
            st.metric(
                label="Sensibilidad Sensorial",
                value=f"{sensibilidad_rep:.2f}",
                delta="ELEVADA" if sensibilidad_rep >= 0.6 else "MODERADA" if sensibilidad_rep >= 0.4 else "BAJA",
                delta_color="inverse" if sensibilidad_rep >= 0.6 else "off"
            )

        if neurodiv.get('nd_score', 0.5) >= 0.6:
            st.warning("⚠️ Los indicadores sugieren posibles dificultades de procesamiento cognitivo. Se recomienda consulta con especialista para evaluación formal.")

    # ================================================================
    # 9. TEXTO ANALIZADO
    # ================================================================
    if texto_snippet and texto_snippet.strip() and texto_snippet != "N/A":
        st.markdown("---")
        st.subheader("📝 Contenido Analizado")
        st.markdown(f"""
        <div style='background:#1a1a2e;padding:15px;border-radius:8px;
        border-left:4px solid #4fc3f7;color:#e0e0e0;font-style:italic;margin:10px 0;'>
        "{texto_snippet}"
        </div>
        """, unsafe_allow_html=True)
        st.caption("Texto analizado con NLP para extraer indicadores emocionales y cognitivos.")

    # ================================================================
    # 10. DISCLAIMER PROFESIONAL
    # ================================================================
    st.markdown("---")
    st.markdown("""
    <div style='
        background-color: #2d2d00;
        border: 1px solid #ffaa00;
        border-radius: 8px;
        padding: 15px;
        margin: 20px 0;
        font-size: 0.9em;
        color: #ffd966;
    '>
    <strong>⚠️ DECLARACIÓN DE RESPONSABILIDAD PROFESIONAL</strong><br><br>
    Este reporte ha sido generado mediante un sistema automatizado de detección temprana. 
    Tiene un carácter <strong>PREVENTIVO, ORIENTATIVO Y NO DIAGNÓSTICO</strong>.<br><br>
    <strong>NO sustituye</strong> la evaluación, diagnóstico o tratamiento por parte de 
    un profesional de la salud mental calificado.<br><br>
    <em>Plataforma de Detección Temprana - Versión 3.0 © 2026</em>
    </div>
    """, unsafe_allow_html=True)
# ================================================================
# ALERTA INTELIGENTE 2.0 (Reglas Psicometricas)
# ================================================================

def generate_smart_alerts(user_id):
    """Genera alertas complejas analizando el historial del usuario."""
    df = fetch_ultimas_sesiones_usuario_para_alertas(user_id, limit=5)

    if df.shape[0] < 2:
        return ["🟢 Bajo riesgo: Se necesitan más sesiones para análisis de tendencia."]
    
    # Preprocesar datos
    df["detalle_json"] = df["detalle"].apply(safe_json_load)
    df["puntaje_num"] = df["puntaje"].apply(safe_float)
    df["tension"] = df["detalle_json"].apply(lambda x: safe_float(x.get("POMS", {}).get("tension", 0)))
    df["valence"] = df["detalle_json"].apply(lambda x: safe_float(x.get("VA", {}).get("valence", 0)))
    
    # Lista de alertas
    alerts = []
    
    # --- Regla 1: Caída de Motivación / POMS ---
    avg_valence = df["valence"].mean()
    if avg_valence < 0.4 and df["valence"].iloc[0] < avg_valence:
        alerts.append("🟡 **Caída de Motivación (Valence Bajo):** El estado de ánimo reciente es significativamente bajo.")

    # --- Regla 2: Aumento Sostenido de Tensión (Estrés POMS) ---
    if df.shape[0] >= 3:
        tension_avg_last_3 = df["tension"].head(3).mean()
        if df["tension"].iloc[0] > (tension_avg_last_3 * 1.25) and tension_avg_last_3 > 0.5: 
            alerts.append("🔴 **Aumento de Tensión POMS:** El nivel de estrés actual excede el promedio histórico reciente.")

    # --- Regla 3: Riesgo Lingüístico de Agotamiento (NLP) ---
    neg_words = df["detalle_json"].iloc[0].get("NegWords", 0)
    if neg_words >= 4:
        alerts.append("🔴 **Riesgo Lingüístico:** Uso elevado de lenguaje negativo o crítico en la última sesión.")

    # --- Regla 4: Inestabilidad (Variabilidad en puntaje) ---
    std_puntaje = df["puntaje_num"].std()
    if std_puntaje > 1.5: 
        alerts.append("🟡 **Inestabilidad:** Alta fluctuación en los puntajes globales, indicando inconsistencia emocional.")

    # Alerta por defecto si no hay nada crítico
    riesgo_actual = safe_json_load(df["detalle"].iloc[0]).get("Riesgo", "Bajo")
    
    if not alerts and riesgo_actual in ["Alto", "Medio"]:
        alerts.append(f"🟢 **Revisión General:** Riesgo actual detectado: {riesgo_actual}. No hay tendencias históricas claras.")
    elif not alerts:
        alerts.append("🟢 **Bajo Riesgo Estructural:** Perfil emocional estable y baja incidencia de factores de riesgo.")

    return alerts


# ================================================================
# INSIGHTS IA 
# ================================================================
def generar_insights_clusters(cluster_summary):
    insights = []

    for _, row in cluster_summary.iterrows():
        cluster = int(row["cluster"])
        puntaje = row.get("puntaje", 0)
        tension = row.get("tension", 0)
        fatigue = row.get("fatigue", 0)
        valence = row.get("valence", 0)

        # 🔴 ALTO RIESGO
        if puntaje > 4:
            insights.append(
                f"🔴 Grupo {cluster}: presenta un nivel de riesgo elevado, con señales consistentes de malestar emocional. Se recomienda atención prioritaria."
            )

        # 🟡 RIESGO MEDIO
        elif puntaje > 3:
            insights.append(
                f"🟡 Grupo {cluster}: muestra indicadores moderados de riesgo. Se sugiere seguimiento para prevenir un posible deterioro."
            )

        # 🟢 BAJO RIESGO
        else:
            insights.append(
                f"🟢 Grupo {cluster}: mantiene un estado emocional estable en general."
            )

        # 🔥 DETALLES ADICIONALES (solo si aportan valor)

        if tension > 0.6:
            insights.append(
                f"   • Se detectan niveles elevados de tensión, lo que puede indicar estrés sostenido."
            )

        if fatigue > 0.7:
            insights.append(
                f"   • Hay signos de fatiga significativa, posible sobrecarga emocional o agotamiento."
            )

        if valence < 0:
            insights.append(
                f"   • El estado emocional tiende a ser negativo, lo que sugiere bajo bienestar percibido."
            )

    return insights



# ================================================================
# PANEL DOCENTE - CLUSTERING DE RIESGO
# ================================================================
    
def show_panel_docente():
    
    st.title("🧠 Panel Docente — Análisis de Agrupación (Clustering)")
    st.caption("Identifica grupos de estudiantes con patrones de riesgo emocional similares.")

    if not SKLEARN_AVAILABLE:
        st.error("🚨 La librería Scikit-learn (sklearn) no está instalada. Ejecuta: pip install scikit-learn")
        return

    df = fetch_resultados_clustering()

    if df.empty:
        st.info("No hay datos suficientes para realizar el clustering.")
        return

    # 1. Preparación de datos (usando la encuesta más reciente por usuario)

    df["data"] = df["detalle"].apply(safe_json_load)

    df["tension"] = df["data"].apply(lambda x: (x or {}).get("poms", {}).get("tension", 0))
    df["fatigue"] = df["data"].apply(lambda x: (x or {}).get("poms", {}).get("fatigue", 0))
    df["valence"] = df["data"].apply(lambda x: (x or {}).get("va", {}).get("valence", 0))
    df["arousal"] = df["data"].apply(lambda x: (x or {}).get("va", {}).get("arousal", 0))

    # FIX REAL: simplificado (tu versión era redundante)
    df["palabras_negativas"] = df["data"].apply(
        lambda x: (x or {}).get("emocional", {}).get("neg_words", 0)
    )

    # FILTRO GLOBAL (ANTES DE TODO)
    df = df.dropna(subset=["valence", "arousal", "palabras_negativas"])

    # FIX REAL: evitar strings o NaN ocultos
    df["valence"] = pd.to_numeric(df["valence"], errors="coerce")
    df["arousal"] = pd.to_numeric(df["arousal"], errors="coerce")
    df["palabras_negativas"] = pd.to_numeric(df["palabras_negativas"], errors="coerce")

    df = df.dropna(subset=["valence", "arousal", "palabras_negativas"])

    df_latest = df.sort_values(by='fecha', ascending=False).drop_duplicates(subset=['usuario_id'])

    # 🔥 ASEGURAR QUE EXISTEN (FIX REAL)
    df_universidad = df_latest[df_latest["nivel"] == "Universidad"].copy()
    df_otros = df_latest[df_latest["nivel"] != "Universidad"].copy()

    # ========================
    # CLUSTERING UNIVERSIDAD (CON POMS)
    # ========================
    features_uni = ['puntaje', 'tension', 'fatigue', 'valence', 'arousal', 'palabras_negativas']
   

    # 🔥 FIX: copy() para evitar SettingWithCopyWarning
    X_uni = df_universidad[features_uni].fillna(0).copy()

    # 🔥 FIX: asegurar tipos numéricos reales
    X_uni = X_uni.apply(pd.to_numeric, errors="coerce").fillna(0)

    # 🔥 PROTECCIÓN: evitar clusters basura
    if X_uni.var().sum() == 0 or len(X_uni) < 2:
        st.warning("Datos insuficientes o constantes en Universidad → clustering no significativo")
        df_universidad["cluster"] = -1
    else:

        feature_weights = {
            "puntaje": 2.0,
            "tension": 1.5,
            "fatigue": 1.5,
            "valence": 2.0,
            "arousal": 2.0,
            "palabras_negativas": 1.2
        }

        # 🔥 FIX: evitar modificar view original
        X_uni_weighted = X_uni.copy()
        for col, w in feature_weights.items():
            if col in X_uni_weighted.columns:
                X_uni_weighted[col] = X_uni_weighted[col] * w

        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_uni_weighted)

        # 🔥 FIX REAL: K seguro
        k = min(num_clusters, len(X_uni_weighted))
        
        if k < 2:
            df_universidad["cluster"] = -1
        else:
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            df_universidad["cluster"] = kmeans.fit_predict(X_scaled)


    # ========================
    # CLUSTERING OTROS (SIN POMS)
    # ========================
    features_base = ['puntaje', 'valence', 'arousal', 'palabras_negativas']

    # 🔥 FIX: copy + tipos
    X_base = df_otros[features_base].fillna(0).copy()
    X_base = X_base.apply(pd.to_numeric, errors="coerce").fillna(0)

    if X_base.var().sum() == 0 or len(X_base) < 2:
        st.warning("Datos insuficientes o constantes en niveles básicos → clustering no significativo")
        df_otros["cluster"] = -1
    else:

        X_base_weighted = X_base.copy()

        for col, w in {
            "puntaje": 2.0,
            "valence": 2.0,
            "arousal": 2.0,
            "palabras_negativas": 1.2
        }.items():
            if col in X_base_weighted.columns:
                X_base_weighted[col] = X_base_weighted[col] * w

        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_base_weighted)

        # 🔥 FIX REAL: K seguro
        k = min(num_clusters, len(X_base_weighted))

        if k < 2:
            df_otros["cluster"] = -1
        else:
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            df_otros["cluster"] = kmeans.fit_predict(X_scaled)


    # ========================
    # UNIR RESULTADOS
    # ========================

    df_final = pd.concat([df_universidad, df_otros], ignore_index=True)

    # ========================
    # 🔥 INTERPRETACIÓN REAL DE CLUSTERS
    # ========================

    cluster_risk = (
        df_final.groupby("cluster")["puntaje"]
        .mean()
        .sort_values()
    )

    ordered_clusters = cluster_risk.index.tolist()

    if num_clusters == 2:
        labels_ordered = [
            "🟢 Estables",
            "🔴 Críticos"
        ]
    else:
        labels_ordered = [
            "🟢 Estables",
            "🟡 Vulnerables",
            "🔴 Críticos"
        ]

    cluster_labels = {
        cluster_id: labels_ordered[i]
        for i, cluster_id in enumerate(ordered_clusters)
    }

    # 4. Aplicar etiquetas
    df_final["cluster_name"] = df_final["cluster"].map(cluster_labels)

    df_final = df_final[df_final["cluster"] != -1].copy()

    # 🔥 FIX: protección real
    if df_final.empty:
        st.warning("No hay datos suficientes después del clustering")
        return





    # 3. Configuración del Clustering
    st.sidebar.subheader("⚙️ Configuración de Clustering")
    
    # Selector de número de clusters (grupos de riesgo)
    num_clusters = st.sidebar.slider("Número de Grupos (K):", min_value=2, max_value=3, value=3)

    st.subheader(f"Grupos de Riesgo (K={num_clusters})")

    # 5. Visualización (Reducción de dimensionalidad con PCA para Plotly)
    features_all = ['puntaje', 'valence', 'arousal', 'palabras_negativas']

    X_vis = df_final[features_all].fillna(0)

    if len(X_vis) < 2:
        st.warning("No hay suficientes datos para visualización PCA.")
        return

    pca = PCA(n_components=2)

    X_vis_scaled = StandardScaler().fit_transform(X_vis)
    components = pca.fit_transform(X_vis_scaled)

    pca_df = pd.DataFrame(components, columns=['PCA Componente 1', 'PCA Componente 2'])
    pca_df['cluster'] = df_final['cluster'].values
    pca_df['usuario_id'] = df_final['usuario_id'].values
    pca_df['puntaje'] = df_final['puntaje'].values

    pca_df = pca_df.merge(
        df_final[["usuario_id", "riesgo_label"]],
        on="usuario_id",
        how="left"
    )
    
    # Scatter plot de Clustering (PCA)
    fig_pca = px.scatter(
        pca_df, 
        x='PCA Componente 1', 
        y='PCA Componente 2', 
        color="riesgo_label",
        color_discrete_map=RISK_COLORS,
        hover_data={'usuario_id': True, 'puntaje': ':.2f', 'cluster': True},
        title="Visualización de Clústeres de Riesgo (Reducción de Dimensionalidad PCA)"
    )
    st.plotly_chart(fig_pca, use_container_width=True)
    
        # 6. Cluster Interpretation (Average Profile Table)
    st.subheader("Perfil Promedio de cada Grupo")
    
    try:
        # 6.1 Calcular estadísticas básicas por cluster (solo features)
        cluster_stats = df_final.groupby('cluster')[[
            'puntaje',
            'tension',
            'fatigue',
            'valence',
            'arousal',
            'palabras_negativas'
        ]].mean().reset_index()
        
        # 6.2 Calcular nivel más frecuente por cluster (separadamente)
        nivel_por_cluster = df_final.groupby('cluster')['nivel'].agg(
            lambda x: x.mode()[0] if not x.mode().empty else 'N/A'
        ).reset_index(name='nivel_mas_frecuente')
        
        # 6.3 Contar miembros por cluster (usando usuario_id correctamente)
        miembros_por_cluster = df_final.groupby('cluster')['usuario_id'].count().reset_index(name='total_miembros')
        
        # 6.4 Combinar todas las estadísticas
        cluster_summary = pd.merge(cluster_stats, nivel_por_cluster, on='cluster')
        cluster_summary = pd.merge(cluster_summary, miembros_por_cluster, on='cluster')
        
        # 6.5 Formatear números para mejor visualización
        for col in ['puntaje', 'tension', 'fatigue', 'valence', 'arousal', 'palabras_negativas']:
            if col in cluster_summary.columns:
                cluster_summary[col] = cluster_summary[col].round(3)
        
        # 6.6 Mostrar tabla con estilo
        st.dataframe(
            cluster_summary.style.background_gradient(
                cmap='RdYlGn_r',  # Rojo = alto riesgo, Verde = bajo riesgo
                subset=['puntaje', 'tension', 'fatigue']
            ).format({
                'puntaje': '{:.2f}',
                'tension': '{:.3f}',
                'fatigue': '{:.3f}',
                'valence': '{:.3f}',
                'arousal': '{:.3f}',
                'palabras_negativas': '{:.1f}'
            }),
            use_container_width=True
        )
        
        # 6.7 Explicación de las métricas
        with st.expander("📊 ¿Qué significan estas métricas?"):
            st.markdown("""
            **Explicación de las columnas:**
            
            - **cluster**: Grupo identificado por el algoritmo
            - **puntaje**: Puntaje de riesgo combinado (0-1, mayor = más riesgo)
            - **tension**: Subescala de tensión POMS (0-1, mayor = más tensión)
            - **fatigue**: Subescala de fatiga POMS (0-1, mayor = más fatiga)  
            - **valence**: Placer/Displacer (-1 a +1, positivo = placentero)
            - **arousal**: Activación (0 a 1, mayor = más activación)
            - **palabras_negativas**: Conteo de palabras negativas en texto libre
            - **nivel_mas_frecuente**: Nivel educativo más común en el grupo
            - **total_miembros**: Número de usuarios distintos en el grupo
            
            **Interpretación:**
            - **puntaje ≥ 0.65**: riesgo alto
            - **0.40 ≤ puntaje < 0.65**: riesgo medio
            - **puntaje < 0.40**: riesgo bajo
            - **tension > 0.6**: tensión elevada
            - **fatigue > 0.7**: fatiga elevada
            - **valence negativo** indica estado de ánimo displacentero
            """)

            # ========================
            # 7. INSIGHTS AUTOMÁTICOS
            # ========================
            st.subheader("🧠 Insights Automáticos")

            insights = generar_insights_clusters(cluster_summary)

            if insights:
                for i in insights:
                    st.markdown(f"- {i}")
            else:
                st.info("No se detectaron patrones relevantes.")
            
    except Exception as e:
        st.error(f"❌ Error al calcular estadísticas de clusters: {str(e)}")
        st.info("Para depuración - Columnas disponibles en df_latest:")
        st.write(list(df_latest.columns))
        st.info("Primeras filas de datos:")
        st.write(df_latest.head())

# ================================================================
# DASHBOARD EMOCIONAL HISTÓRICO - EVOLUCIÓN TEMPORAL
# ================================================================

def show_dashboard_historico():
    
    st.title("📈 Dashboard Emocional Histórico")
    st.markdown("Análisis de evolución temporal de los indicadores emocionales.")
    
    df = fetch_dashboard_historico()
    
    if df.empty:
        st.info("No hay datos históricos para mostrar.")
        return
    
    # Procesar datos
    df["detalle_json"] = df["detalle"].apply(safe_json_load)
    df["respuestas_json"] = df["respuestas"].apply(safe_json_load)
    df["fecha_dt"] = pd.to_datetime(df["fecha"])
    
    # Extraer información estructurada según el contrato actual de datos
    df["perfil"] = df["detalle_json"].apply(
    lambda x: (x or {}).get("resultado", {}).get("perfil", "No definido")
    )

    df["valence"] = df["detalle_json"].apply(
        lambda x: (x or {}).get("va", {}).get("valence", 0.0)
    )

    df["arousal"] = df["detalle_json"].apply(
        lambda x: (x or {}).get("va", {}).get("arousal", 0.5)
    )

    df["poms_tension"] = df["detalle_json"].apply(
        lambda x: (x or {}).get("poms", {}).get("tension", np.nan)
    )

    df["poms_fatigue"] = df["detalle_json"].apply(
        lambda x: (x or {}).get("poms", {}).get("fatiga", np.nan)
    )

    df["poms_vigor"] = df["detalle_json"].apply(
        lambda x: (x or {}).get("poms", {}).get("vigor", np.nan)
    )
    
    # Extraer datos de la encuesta base
    def extract_base_value(respuestas, key):
        try:
            # Primero intenta directo, luego dentro de "base"
            valor = respuestas.get(key)
            if valor is None:
                valor = respuestas.get("base", {}).get(key, 3)
            return valor if valor is not None else 3
        except:
            return 3
    
    df["base_estres"]     = df["respuestas_json"].apply(lambda x: extract_base_value(x, "estres"))
    df["base_motivacion"] = df["respuestas_json"].apply(lambda x: extract_base_value(x, "social"))
    df["base_animo"]      = df["respuestas_json"].apply(lambda x: extract_base_value(x, "animo"))
    
    # ===== FILTROS DE ANÁLISIS =====
    st.sidebar.subheader("🎛️ Filtros de Análisis")

    niveles = ["Todos"] + sorted(df["usuario_nivel"].dropna().unique().tolist())
    nivel_seleccionado = st.sidebar.selectbox(
        "Filtrar Nivel:",
        niveles
    )

    df_filtered = df.copy()

    if nivel_seleccionado != "Todos":
        df_filtered = df_filtered[
            df_filtered["usuario_nivel"] == nivel_seleccionado
        ]

    df = df_filtered
    
    if df.empty:
        st.warning("No hay datos para la combinación de filtros seleccionada.")
        return
        
    # Filtro por fecha (usando el DataFrame ya filtrado)
    fecha_min = df["fecha_dt"].min()
    fecha_max = df["fecha_dt"].max()
    
    if pd.isna(fecha_min): # Pequeña validación si el filtro de usuario/nivel deja el DF vacío
         st.warning("No hay datos en el rango seleccionado después de aplicar el filtro de usuario/nivel.")
         return
    
    rango_fechas = st.sidebar.date_input(
        "Rango de fechas:",
        value=(fecha_min.date(), fecha_max.date()),
        min_value=fecha_min.date(),
        max_value=fecha_max.date()
    )
    
    if len(rango_fechas) == 2:
        df = df[
            (df["fecha_dt"].dt.date >= rango_fechas[0]) & 
            (df["fecha_dt"].dt.date <= rango_fechas[1])
        ]
    
    if df.empty:
        st.warning("No hay datos en el rango seleccionado.")
        return
    

    if len(df) < 2:
        st.info(
            "No hay suficientes evaluaciones para mostrar una evolución histórica. "
            "Se requiere más de una evaluación."
        )
        return
    
    # ===== EVOLUCIÓN GENERAL (Se añade el nombre del usuario al título) =====
    st.header("📊 Evolución General del Bienestar")
    
    # Agrupar por fecha para tendencias
    df_diario = df.groupby(df["fecha_dt"].dt.date).agg({
        "puntaje": "mean",
        "base_estres": "mean",
        "base_motivacion": "mean", 
        "base_animo": "mean",
        "poms_tension": "mean",
        "poms_fatigue": "mean",
        "poms_vigor": "mean",
        "valence": "mean",
        "arousal": "mean",
        "id": "count"
    }).reset_index()
    
    df_diario.columns = ["fecha", "puntaje_promedio", "estres_promedio", "motivacion_promedio", 
                         "animo_promedio", "tension_promedio", "fatiga_promedio", "vigor_promedio",
                         "valence_promedio", "arousal_promedio", "num_encuestas"]
    
    # Determinar el título dinámico
    title_suffix = f" (Nivel: {nivel_seleccionado})" if nivel_seleccionado != "Todos" else ""

    # Gráfico de evolución del puntaje
    fig_puntaje = px.line(
        df_diario, x="fecha", y="puntaje_promedio",
        title=f"📈 Evolución del Puntaje de Bienestar/Riesgo Promedio{title_suffix}", # <--- Título dinámico
        labels={"fecha": "Fecha", "puntaje_promedio": "Puntaje Promedio"},
        markers=True
    )
    fig_puntaje.add_hline(y=0.65, line_dash="dash", line_color="red", annotation_text="Límite Riesgo Alto")
    fig_puntaje.add_hline(y=0.40, line_dash="dash", line_color="orange", annotation_text="Límite Riesgo Medio")
    st.plotly_chart(fig_puntaje, use_container_width=True)

    st.caption("La línea muestra la evolución del puntaje promedio. " "Los umbrales de 0.40 y 0.65 permiten identificar zonas de seguimiento y alerta.")
    with st.expander("¿Cómo leer este gráfico?"):
        st.markdown("""
        Muestra la evolución del puntaje de riesgo promedio a lo largo del tiempo.
        - **Por encima de 0.65**: zona de riesgo alto — requiere atención.
        - **Entre 0.40 y 0.65**: zona media — seguimiento recomendado.
        - **Por debajo de 0.40**: zona estable — situación favorable.
        
        *Una tendencia ascendente sostenida es más preocupante que un pico aislado.*
        """)
    
    # ===== EVOLUCIÓN DE ESTRÉS Y MOTIVACIÓN =====
    st.header("😌 Evolución de Estrés y Motivación")
    
    col1, col2 = st.columns(2)
    
    with col1:
        fig_estres = px.line(
            df_diario, x="fecha", y="estres_promedio",
            title="📊 Evolución del Estrés Promedio",
            labels={"fecha": "Fecha", "estres_promedio": "Estrés (1-5)"},
            markers=True,
            color_discrete_sequence=["red"]
        )
        st.plotly_chart(fig_estres, use_container_width=True)
    
    with col2:
        fig_motivacion = px.line(
            df_diario, x="fecha", y="motivacion_promedio",
            title="🚀 Evolución de la Motivación Promedio", 
            labels={"fecha": "Fecha", "motivacion_promedio": "Motivación (1-5)"},
            markers=True,
            color_discrete_sequence=["green"]
        )
        st.plotly_chart(fig_motivacion, use_container_width=True)
    
    # ===== EVOLUCIÓN POMS =====
    st.header("🧠 Evolución de Estados Afectivos (POMS)")
    
    fig_poms = go.Figure()
    
    fig_poms.add_trace(go.Scatter(
        x=df_diario["fecha"], y=df_diario["tension_promedio"],
        name="Tensión", line=dict(color="red", width=3)
    ))
    fig_poms.add_trace(go.Scatter(
        x=df_diario["fecha"], y=df_diario["fatiga_promedio"], 
        name="Fatiga", line=dict(color="orange", width=3)
    ))
    fig_poms.add_trace(go.Scatter(
        x=df_diario["fecha"], y=df_diario["vigor_promedio"],
        name="Vigor", line=dict(color="green", width=3)
    ))
    
    fig_poms.update_layout(
        title="📊 Evolución de Estados Afectivos - POMS",
        xaxis_title="Fecha",
        yaxis_title="Intensidad (0-1)",
        hovermode="x unified"
    )
    
    st.plotly_chart(fig_poms, use_container_width=True)
    
    # ===== EVOLUCIÓN VALENCE-AROUSAL =====
    st.header("🎭 Evolución de la Dimensión Emocional (VA)")
    
    col1, col2 = st.columns(2)
    
    with col1:
        fig_valence = px.line(
            df_diario, x="fecha", y="valence_promedio",
            title="😊 Evolución de Valence (Placer)",
            labels={"fecha": "Fecha", "valence_promedio": "Valence (-1 a +1)"},
            markers=True,
            color_discrete_sequence=["blue"]
        )
        fig_valence.add_hline(y=0, line_dash="dash", line_color="gray")
        st.plotly_chart(fig_valence, use_container_width=True)
    
    with col2:
        fig_arousal = px.line(
            df_diario, x="fecha", y="arousal_promedio", 
            title="⚡ Evolución de Arousal (Activación)",
            labels={"fecha": "Fecha", "arousal_promedio": "Arousal (0 a 1)"},
            markers=True,
            color_discrete_sequence=["purple"]
        )
        st.plotly_chart(fig_arousal, use_container_width=True)
    
    # ===== ANÁLISIS DE TENDENCIAS =====
    st.header("📈 Análisis de Tendencias")
    
    if len(df_diario) >= 2:
        # Calcular tendencias por día real transcurrido
        dias_transcurridos = max(
            1,
            (df_diario["fecha"].max() - df_diario["fecha"].min()).days
        )

        tendencia_puntaje = (
            df_diario["puntaje_promedio"].iloc[-1]
            - df_diario["puntaje_promedio"].iloc[0]
        ) / dias_transcurridos

        tendencia_estres = (
            df_diario["estres_promedio"].iloc[-1]
            - df_diario["estres_promedio"].iloc[0]
        ) / dias_transcurridos

        tendencia_motivacion = (
            df_diario["motivacion_promedio"].iloc[-1]
            - df_diario["motivacion_promedio"].iloc[0]
        ) / dias_transcurridos

        col1, col2, col3 = st.columns(3)
        
        with col1:
            color_puntaje = "red" if tendencia_puntaje > 0.01 else "green" if tendencia_puntaje < -0.01 else "gray"
            st.metric(
                "Tendencia Riesgo", 
                f"{tendencia_puntaje:+.3f} por día",
                delta=f"{tendencia_puntaje:+.3f}",
                delta_color="inverse"
            )
        
        with col2:
            color_estres = "red" if tendencia_estres > 0.01 else "green" if tendencia_estres < -0.01 else "gray"
            st.metric(
                "Tendencia Estrés",
                f"{tendencia_estres:+.3f} por día", 
                delta=f"{tendencia_estres:+.3f}",
                delta_color="inverse"
            )
        
        with col3:
            color_motivacion = "green" if tendencia_motivacion > 0.01 else "red" if tendencia_motivacion < -0.01 else "gray"
            st.metric(
                "Tendencia Motivación",
                f"{tendencia_motivacion:+.3f} por día",
                delta=f"{tendencia_motivacion:+.3f}"
            )
    
    # ===== RESUMEN ESTADÍSTICO =====
    st.header("📋 Resumen Estadístico")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Encuestas", len(df))
        st.metric("Período Analizado", f"{(df['fecha_dt'].max() - df['fecha_dt'].min()).days} días")
    
    with col2:
        fecha_actual = df["fecha_dt"].dt.date.max()

        riesgo_actual = df[
            df["fecha_dt"].dt.date == fecha_actual
        ]["riesgo"].value_counts()

        if "Alto" in riesgo_actual:
            st.metric("Riesgo Alto Actual", riesgo_actual["Alto"])
        else:
            st.metric("Riesgo Alto Actual", 0)
    
    with col3:
        st.metric("Puntaje Promedio Actual", f"{df_diario['puntaje_promedio'].iloc[-1]:.2f}")
        st.metric("Encuestas por Día", f"{df_diario['num_encuestas'].mean():.1f}")
    
    st.success("✅ Dashboard histórico cargado correctamente")

# ================================================================
# DASHBOARD PROFESIONAL (Función final con todos los gráficos Plotly)
# ================================================================

def show_dashboard_profesional():
    st.title("👨‍🏫 Dashboard de Bienestar General")
    st.markdown("Vista global y comparativa de los indicadores emocionales por grupo y nivel.")

    try:
        df = fetch_dashboard_profesional()
        df = apply_riesgo_labels(df)
    except pd.io.sql.DatabaseError as e:
        st.error(f"Error al ejecutar consulta SQL para dashboard: {e}")
        st.info("Asegúrate de que las tablas existan y la base de datos esté inicializada.")
        return

    if df.empty:
        st.info("No hay datos cargados para generar el dashboard.")
        return

    # Procesamiento y Extracción
    df["detalle_json"] = df["detalle"].apply(safe_json_load)
    
    # Extraer perfil emocional
    df["perfil"] = df["detalle_json"].apply(lambda x: x.get("resultado", {}).get("perfil", "No definido"))
    
    # Extracción de métricas
    df["valence"] = df["detalle_json"].apply(
    lambda x: (x or {}).get("va", {}).get("valence", 0)
    )

    df["arousal"] = df["detalle_json"].apply(
        lambda x: (x or {}).get("va", {}).get("arousal", 0.5)
    )

    df["tension"] = df["detalle_json"].apply(
        lambda x: (x or {}).get("poms", {}).get("tension", np.nan)
    )

    df["fatigue"] = df["detalle_json"].apply(
        lambda x: (x or {}).get("poms", {}).get("fatiga", np.nan)
    )

    df["vigor"] = df["detalle_json"].apply(
        lambda x: (x or {}).get("poms", {}).get("vigor", np.nan)
    )
    
    # ================================================================
    # FILTROS
    # ================================================================
    st.sidebar.subheader("🎛️ Filtros Globales")
    
    # Filtro por nivel
    niveles_unicos = ["Todos"] + sorted(df["nivel"].unique().tolist())
    nivel_seleccionado = st.sidebar.selectbox("Filtrar por Nivel:", niveles_unicos)

    if nivel_seleccionado != "Todos":
        df = df[df["nivel"] == nivel_seleccionado]
        
    if df.empty:
        st.warning("No hay datos para el nivel seleccionado.")
        return
        
    # ================================================================
    # 1. Indicadores de Riesgo y Perfiles
    # ================================================================
    st.header("1. Distribución de Indicadores Clave")
    col1, col2 = st.columns(2)
    
    # Gráfico de Riesgo (Pie Chart)
    with col1:
        riesgo_counts = df["riesgo"].value_counts().reset_index()
        riesgo_counts.columns = ['riesgo', 'count']
        
        # Mapa de colores para Riesgo
        riesgo_counts["riesgo_label"] = riesgo_counts["riesgo"].map(RISK_LABELS)
        
        fig_riesgo = px.pie(
            riesgo_counts,
            values='count',
            names='riesgo_label',
            title='¿Cuántos estudiantes están en cada nivel de riesgo?',
            color='riesgo_label',
            color_discrete_map=RISK_COLORS
        )
        fig_riesgo.update_traces(textinfo='percent+label', marker=dict(line=dict(color='#000000', width=1)))
        st.plotly_chart(fig_riesgo, use_container_width=True)
        st.caption("🔴 Alto: requiere atención inmediata | 🟡 Medio: seguimiento recomendado | 🟢 Bajo: situación estable")
        with st.expander("¿Cómo leer este gráfico?"):
            st.markdown("""
            Este gráfico muestra la proporción de estudiantes según su nivel de riesgo emocional detectado.
            - **Riesgo Alto**: el sistema detectó señales significativas de malestar emocional que requieren atención prioritaria.
            - **Riesgo Medio**: hay indicadores moderados que merecen seguimiento.
            - **Riesgo Bajo**: el estudiante muestra un estado emocional estable.
            
            *Un porcentaje alto en rojo no es un diagnóstico — es una señal para iniciar conversaciones de apoyo.*
            """)

    # Gráfico de Perfiles Emocionales (Barra)
    with col2:
        perfil_counts = df["perfil"].value_counts().reset_index()
        perfil_counts.columns = ['perfil', 'count']
        fig_perfiles = px.bar(
            perfil_counts, x="perfil", y="count",
            title="¿Qué patrones emocionales predominan en el grupo?",
            text_auto=True,
            color='perfil',
            color_discrete_sequence=px.colors.qualitative.D3
        )
        st.plotly_chart(fig_perfiles, use_container_width=True)
        st.caption("Cada barra representa cuántos estudiantes comparten un patrón emocional similar.")
        with st.expander("¿Cómo leer este gráfico?"):
            st.markdown("""
            Los perfiles emocionales describen el patrón predominante detectado en cada estudiante:
            - **Resiliente**: buena capacidad de adaptación ante el estrés.
            - **Ansioso/Tenso**: niveles elevados de tensión y activación del sistema de alerta.
            - **Fatigado**: agotamiento mental o físico significativo.
            - **Inestable emocional**: fluctuaciones emocionales sin patrón claro.
            - **Riesgo neuro-afectivo**: indicadores de malestar psicológico más profundo.
            - **Perfil mixto**: múltiples factores activos sin patrón dominante.
            
            *El perfil más frecuente orienta qué tipo de intervención grupal podría ser más útil.*
            """)

    # ================================================================
    # 2. Análisis POMS y Dimensión Emocional VA
    # ================================================================
    st.header("2. Métricas Afectivas Avanzadas")
    
    col3, col4 = st.columns(2)
    
    # Gráfico de Dispersión Valence-Arousal (VA)
    with col3:
        fig_va = px.scatter(
            df, x="valence", y="arousal",
            color="riesgo_label",
            color_discrete_map=RISK_COLORS,
            hover_data=["perfil"],
            title="Mapa emocional del grupo: ¿cómo se sienten y qué tanta energía tienen?",
            range_x=[-1.1, 1.1],
            range_y=[-0.1, 1.1]
        )
        fig_va.add_shape(type="line", x0=-1, y0=0.5, x1=1, y1=0.5, line=dict(dash="dash", color="gray"))
        fig_va.add_shape(type="line", x0=0, y0=0, x1=0, y1=1, line=dict(dash="dash", color="gray"))
        st.plotly_chart(fig_va, use_container_width=True)
        st.caption("Cada punto es un estudiante. Cuadrante superior derecho = activo y positivo. Inferior izquierdo = desanimado y sin energía.")
        with st.expander("¿Cómo leer este gráfico?"):
            st.markdown("""
            Este mapa ubica a cada estudiante según dos dimensiones emocionales:
            
            - **Eje horizontal (Placer)**: va de -1 (muy negativo) a +1 (muy positivo). Indica qué tan agradable es el estado emocional.
            - **Eje vertical (Activación)**: va de 0 (muy tranquilo) a 1 (muy activado). Indica el nivel de energía o alerta.
            
            **Los 4 cuadrantes significan:**
            - Superior derecho ↗: Activo y positivo — motivado, enérgico.
            - Superior izquierdo ↖: Activo y negativo — ansioso, estresado.
            - Inferior derecho ↘: Tranquilo y positivo — relajado, sereno.
            - Inferior izquierdo ↙: Tranquilo y negativo — apático, desmotivado.
            
            *Los puntos rojos en el cuadrante superior izquierdo merecen atención prioritaria.*
            """)

    # Gráfico de Radar POMS Promedio por Nivel
    with col4:
        # Agrupamos por Nivel para el radar
        df_poms = df[df["nivel"] == "Universidad"].copy()

        if df_poms.empty:
            st.info("No hay datos POMS disponibles para Universidad.")
        else:
            poms_group = (
                df_poms.groupby("nivel")[["tension", "fatigue", "vigor"]]
                .mean()
                .reset_index()
            )
        poms_group = poms_group.melt(id_vars='nivel', var_name='Métrica', value_name='Valor')
        
        fig_radar = px.line_polar(
            poms_group, r='Valor', theta='Métrica', color='nivel', 
            line_close=True,
            title="Estados afectivos promedio por nivel educativo",
            range_r=[0, poms_group['Valor'].max() * 1.1]
        )
        fig_radar.update_layout(
            polar=dict(
                bgcolor="rgba(0,0,0,0)",
                radialaxis=dict(
                    gridcolor="rgba(255,255,255,0.15)",
                    linecolor="rgba(255,255,255,0.15)",
                    tickfont=dict(color="rgba(255,255,255,0.6)")
                ),
                angularaxis=dict(
                    gridcolor="rgba(255,255,255,0.15)",
                    linecolor="rgba(255,255,255,0.15)",
                    tickfont=dict(color="rgba(255,255,255,0.8)")
                )
            ),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)"
        )
        st.plotly_chart(fig_radar, use_container_width=True)
        st.caption("Tensión y Fatiga altas son señales de alerta. Vigor alto indica buena energía grupal.")
        with st.expander("¿Cómo leer este gráfico?"):
            st.markdown("""
            Este gráfico radar muestra el promedio de tres estados afectivos medidos con la escala POMS:
            
            - **Tensión**: nivel de estrés y nerviosismo del grupo. Valores altos indican sobrecarga.
            - **Fatiga**: nivel de agotamiento mental y físico. Valores altos sugieren burnout grupal.
            - **Vigor**: nivel de energía y vitalidad. Es el único indicador positivo — valores altos son buenos.
            
            *Un triángulo grande en Tensión y Fatiga con un vértice pequeño en Vigor es señal de alerta grupal.*
            """)

    st.markdown("---")
    st.success(f"✅ Dashboard profesional cargado con {len(df)} resultados analizados.")

# ================================================================
# ALERTAS INTELIGENTES
# ================================================================

def show_alertas_inteligentes():
    # Título principal de la sección de Alertas
    st.title("🚨 Alertas de Riesgo Temprano")
    st.write("Análisis focalizado en los casos que presentan mayor puntuación de riesgo combinado (Riesgo Alto).")

    try:
        df = fetch_alertas_riesgo_alto()

        if "riesgo_label" not in df.columns:
            df = apply_riesgo_labels(df)

    except pd.io.sql.DatabaseError as e:
        st.error(f"Error al ejecutar consulta SQL para alertas: {e}")
        st.info("Asegúrate de que las tablas existan y la base de datos esté inicializada.")
        return

    if df.empty:
        st.success("No hay casos en riesgo alto. El bienestar general es satisfactorio. 🟢")
        return

    # Procesamiento y Extracción de datos JSON
    df["detalle_json"] = df["detalle"].apply(safe_json_load)
    df["respuestas_json"] = df["respuestas"].apply(safe_json_load)
    
    # Extraer perfil del JSON
    df["perfil"] = df["detalle_json"].apply(lambda x: x.get("resultado", {}).get("perfil", "No definido"))    

    # Extraer el texto libre de la encuesta para contextualizar la alerta
    df["texto"] = df["respuestas_json"].apply(lambda x: x.get("texto", ""))
    
    # Señales observadas asociadas al caso.
    # No representan diagnóstico ni causa clínica.
    def obtener_senales(d):
        emocional = (d or {}).get("emocional", {})

        neg = emocional.get("neg_words", 0)

        try:
            neg = float(neg)
        except (TypeError, ValueError):
            neg = 0

        señales = []

        if neg >= 3:
            señales.append("Lenguaje con mayor presencia de términos negativos")

        if not señales:
            señales.append("Revisar indicadores del reporte")

        return " | ".join(señales)


    df["Señales observadas"] = df["detalle_json"].apply(obtener_senales)
    
    st.markdown("---")
    st.markdown(f"**{len(df)}** casos detectados en **Riesgo Alto** que requieren atención inmediata.")

    # Tabla de resumen de los casos en riesgo alto
    st.dataframe(
        df[
            [
                "resultado_id",
                "nivel",
                "puntaje",
                "Señales observadas",
                "fecha",
                "riesgo_label"
            ]
        ].rename(
            columns={
                "resultado_id": "ID Resultado",
                "puntaje": "Puntuación",
                "fecha": "Fecha"
            }
        ),
        use_container_width=True,
        hide_index=True
    )

    st.markdown("---")
    st.subheader("🔍 Detalle del Caso Más Crítico")
    
    # Mostrar el detalle del caso con mayor puntaje de riesgo
    df = df.sort_values("puntaje", ascending=False).reset_index(drop=True)
    caso = df.iloc[0]
    det = caso["detalle_json"]
    
    # Se usa show_single_report para mostrar la información estructurada
    with st.expander(
        f"Reporte completo: ID {caso['resultado_id']} | "
        f"Puntaje: {caso['puntaje']:.2f}",
        expanded=True
    ):
         show_single_report(caso['riesgo'], caso['perfil'], det)
         
    st.markdown("---")
    st.info("El análisis de alertas permite la acción temprana por parte del equipo de acompañamiento.")

# ================================================================
# UTILIDADES PDF (ReportLab) - FUNCIONES EXISTENTES
# ================================================================

def generar_pdf_reporte_general_bytes(data):
    """
    Recibe una lista como:
        [["Alto", 10], ["Medio", 5], ["Bajo", 12]]
    Y devuelve bytes PDF.
    """
    if not REPORTLAB_AVAILABLE:
        raise RuntimeError("ReportLab no disponible.")

    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)

    c.setFont("Helvetica-Bold", 16)
    c.drawString(72, 750, "Reporte General — Niveles de Riesgo")

    y = 720
    c.setFont("Helvetica", 12)
    for riesgo, cantidad in data:
        c.drawString(80, y, f"{riesgo}: {cantidad}")
        y -= 20
        if y < 72:
            c.showPage()
            y = 720

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer.getvalue()

def generar_pdf_historial_bytes(usuario_label, df_hist):
    """
    Genera un PDF con el historial de un usuario.
    """
    if not REPORTLAB_AVAILABLE:
        raise RuntimeError("ReportLab no disponible.")

    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)

    c.setFont("Helvetica-Bold", 14)
    c.drawString(72, 750, f"Historial — {usuario_label}")

    c.setFont("Helvetica", 10)
    y = 730
    for _, row in df_hist.iterrows():
        fecha = (
            row["Fecha"].strftime("%Y-%m-%d %H:%M:%S")
            if hasattr(row["Fecha"], "strftime")
            else str(row["Fecha"])
        )
        line = f"{fecha} | Puntaje: {row['Puntaje']:.2f} | Riesgo: {row['Riesgo']}"
        c.drawString(72, y, line)
        y -= 14
        if y < 72:
            c.showPage()
            y = 730

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer.getvalue()

# ================================================================
# EXPORTES AVANZADOS - PDF PROFESIONAL
# ================================================================

def generar_pdf_profesional_bytes(usuario_id=None):
    """
    Genera un PDF profesional con:
    - Diagrama VA
    - Barras POMS
    - Perfil emocional
    - Riesgos detectados
    - Comparativa histórica
    """
    if not REPORTLAB_AVAILABLE:
        raise RuntimeError("ReportLab no disponible.")

    if usuario_id:
        df = fetch_pdf_resultados_por_usuario(usuario_id)
        titulo = f"Reporte Individual - Usuario {usuario_id}"
    else:
        df = fetch_pdf_resultados_por_usuario(None)
        titulo = "Reporte General - Plataforma de Detección Emocional"

    if df.empty:
        raise ValueError("No hay datos para generar el reporte")

    # Procesar datos
    df["detalle_json"] = df["detalle"].apply(safe_json_load)
    df["respuestas_json"] = df["respuestas"].apply(safe_json_load)
    
    # Extraer información importante
    df["perfil"] = df["detalle_json"].apply(
    lambda x: (x or {}).get("resultado", {}).get("perfil", "No definido")
    )

    df["valence"] = df["detalle_json"].apply(
        lambda x: (x or {}).get("va", {}).get("valence", np.nan)
    )

    df["arousal"] = df["detalle_json"].apply(
        lambda x: (x or {}).get("va", {}).get("arousal", np.nan)
    )
    
    # Crear PDF
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    
    # ===== PORTADA =====
    c.setFont("Helvetica-Bold", 18)
    c.drawString(72, 750, titulo)
    c.setFont("Helvetica", 12)
    c.drawString(72, 730, f"Generado el: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    c.drawString(72, 710, f"Total de encuestas: {len(df)}")
    
    # Estadísticas generales
    c.setFont("Helvetica-Bold", 14)
    c.drawString(72, 680, "Resumen Estadístico")
    c.setFont("Helvetica", 10)
    
    riesgo_counts = df['riesgo'].value_counts()
    y_pos = 660
    for riesgo, count in riesgo_counts.items():
        c.drawString(80, y_pos, f"{riesgo}: {count} encuestas ({count/len(df)*100:.1f}%)")
        y_pos -= 15
    
    # Perfiles emocionales
    y_pos -= 10
    c.setFont("Helvetica-Bold", 12)
    c.drawString(72, y_pos, "Perfiles Emocionales:")
    c.setFont("Helvetica", 10)
    y_pos -= 15
    
    perfil_counts = df['perfil'].value_counts()
    for perfil, count in perfil_counts.head(5).items():
        c.drawString(80, y_pos, f"{perfil}: {count}")
        y_pos -= 12
    
    # Si queda poco espacio, nueva página
    if y_pos < 100:
        c.showPage()
        y_pos = 750
    
    # ===== ANÁLISIS DETALLADO =====
    c.setFont("Helvetica-Bold", 14)
    c.drawString(72, y_pos, "Análisis Detallado")
    y_pos -= 20
    
    # Promedios POMS
    c.setFont("Helvetica-Bold", 12)
    c.drawString(72, y_pos, "Estados Afectivos Promedio (POMS):")
    c.setFont("Helvetica", 10)
    y_pos -= 15
    
    poms_promedios = {}

    for sub in ["tension", "fatigue", "vigor"]:
        valores = []

        for detalle in df["detalle_json"]:
            poms_val = (detalle or {}).get("poms", {}).get(sub, np.nan)

            if pd.notna(poms_val):
                valores.append(float(poms_val))

        if valores:
            poms_promedios[sub] = sum(valores) / len(valores)

            c.drawString(
                80,
                y_pos,
                f"{sub.capitalize()}: {poms_promedios[sub]:.3f}"
            )

            y_pos -= 12
    
    # Valence-Arousal promedio
    y_pos -= 10
    c.setFont("Helvetica-Bold", 12)
    c.drawString(72, y_pos, "Dimensión Emocional Promedio (VA):")
    c.setFont("Helvetica", 10)
    y_pos -= 15
    
    valence_prom = df['valence'].mean()
    arousal_prom = df['arousal'].mean()
    c.drawString(80, y_pos, f"Valence: {valence_prom:.3f} ({-1:+} a {1:+})")
    y_pos -= 12
    c.drawString(80, y_pos, f"Arousal: {arousal_prom:.3f} (0 a 1)")
    y_pos -= 15
    
    # ===== RECOMENDACIONES =====
    if y_pos < 150:
        c.showPage()
        y_pos = 750
    
    c.setFont("Helvetica-Bold", 14)
    c.drawString(72, y_pos, "Recomendaciones Generales")
    c.setFont("Helvetica", 10)
    y_pos -= 20
    
    recomendaciones = []
    
    # Análisis de riesgos
    alto_riesgo = riesgo_counts.get('Alto', 0)
    if alto_riesgo > 0:
        recomendaciones.append(f"• {alto_riesgo} casos de alto riesgo requieren atención prioritaria")
    
    if poms_promedios.get('tension', 0) > 0.6:
        recomendaciones.append("• Nivel general de tensión elevado - considerar actividades de relajación")
    
    if valence_prom < -0.2:
        recomendaciones.append("• Valence promedio negativo - fortalecer apoyo emocional")
    
    # Agregar recomendaciones al PDF
    for rec in recomendaciones:
        if y_pos < 100:
            c.showPage()
            y_pos = 750
            c.setFont("Helvetica", 10)
        c.drawString(72, y_pos, rec)
        y_pos -= 15
    
    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer.getvalue()

# ================================================================
# EXPORTES AVANZADOS - EXCEL COMPLETO
# ================================================================

def generar_excel_completo_bytes():
    """
    Genera un archivo Excel completo con múltiples hojas:
    - Resumen general
    - Datos detallados
    - Análisis POMS
    - Valence-Arousal
    - Alertas y riesgos
    """
    df_usuarios, df_encuestas, df_resultados = fetch_excel_export_bundle()
    
    if df_resultados.empty:
        raise ValueError("No hay datos para generar el reporte Excel")
    
    # Procesar datos para análisis
    df_resultados["detalle_json"] = df_resultados["detalle"].apply(safe_json_load)
    df_resultados["respuestas_json"] = df_resultados["respuestas"].apply(safe_json_load)
    
    # Extraer información estructurada
    datos_procesados = []
    for _, row in df_resultados.iterrows():
        detalle = row["detalle_json"]
        respuestas = row["respuestas_json"]
        
        datos_procesados.append({
            "id": row["id"],
            "rol": row["rol"],
            "edad": row["edad"],
            "nivel": row["usuario_nivel"],
            "fecha": row["fecha"],
            "puntaje": row["puntaje"],
            "riesgo": row["riesgo"],
            "perfil": (detalle or {}).get("resultado", {}).get("perfil", "No definido"),
            "valence": (detalle or {}).get("va", {}).get("valence", np.nan),
            "arousal": (detalle or {}).get("va", {}).get("arousal", np.nan),
            "poms_tension": (detalle or {}).get("poms", {}).get("tension", np.nan),
            "poms_fatigue": (detalle or {}).get("poms", {}).get("fatigue", np.nan),
            "poms_vigor": (detalle or {}).get("poms", {}).get("vigor", np.nan),
            "polarity": (detalle or {}).get("emocional", {}).get("polarity", np.nan),
            "neg_words": (detalle or {}).get("emocional", {}).get("neg_words", np.nan),
        })
    
    df_analisis = pd.DataFrame(datos_procesados)
    
    # Crear archivo Excel con múltiples hojas
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
        # Hoja 1: Resumen ejecutivo
        resumen_data = {
            'Métrica': ['Total Usuarios', 'Total Encuestas', 'Total Resultados', 
                       'Riesgo Alto', 'Riesgo Medio', 'Riesgo Bajo',
                       'Fecha de generación'],
            'Valor': [len(df_usuarios), len(df_encuestas), len(df_resultados),
                     len(df_analisis[df_analisis['riesgo'] == 'Alto']),
                     len(df_analisis[df_analisis['riesgo'] == 'Medio']),
                     len(df_analisis[df_analisis['riesgo'] == 'Bajo']),
                     datetime.now().strftime('%Y-%m-%d %H:%M:%S')]
        }
        df_resumen = pd.DataFrame(resumen_data)
        df_resumen.to_excel(writer, sheet_name='Resumen Ejecutivo', index=False)
        
        # Hoja 2: Datos detallados
        df_analisis.to_excel(writer, sheet_name='Datos Detallados', index=False)
        
        # Hoja 3: Análisis POMS
        poms_promedio = df_analisis[['poms_tension', 'poms_fatigue', 'poms_vigor']].mean()
        poms_por_nivel = df_analisis.groupby('nivel')[['poms_tension', 'poms_fatigue', 'poms_vigor']].mean()
        
        poms_data = {
            'Subescala': ['Tensión', 'Fatiga', 'Vigor'],
            'Promedio General': poms_promedio.values
        }
        df_poms = pd.DataFrame(poms_data)
        df_poms.to_excel(writer, sheet_name='Análisis POMS', index=False)
        poms_por_nivel.to_excel(writer, sheet_name='POMS por Nivel')
        
        # Hoja 4: Valence-Arousal
        va_stats = df_analisis[['valence', 'arousal']].describe()
        va_por_riesgo = df_analisis.groupby('riesgo')[['valence', 'arousal']].mean()
        
        va_stats.to_excel(writer, sheet_name='Estadísticas VA')
        va_por_riesgo.to_excel(writer, sheet_name='VA por Riesgo')
        
        # Hoja 5: Perfiles emocionales
        perfiles_count = df_analisis['perfil'].value_counts().reset_index()
        perfiles_count.columns = ['Perfil', 'Cantidad']
        perfiles_count.to_excel(writer, sheet_name='Perfiles Emocionales', index=False)
    
    buffer.seek(0)
    return buffer.getvalue()

# ================================================================
# PÁGINA ACERCA DEL PROYECTO
# ================================================================

def show_acerca():
    st.title("📖 Acerca del Proyecto")
    st.markdown("---")

    # ── Descripción general ────────────────────────────
    st.subheader("🎯 ¿Qué es esta plataforma?")
    st.markdown("""
    <div style='background:rgba(79,195,247,0.08);border-left:4px solid #4fc3f7;
    padding:20px;border-radius:10px;margin:10px 0;color:inherit;'>
    Esta plataforma es un sistema de <strong>detección temprana de riesgos emocionales 
    y cognitivos</strong> en entornos educativos venezolanos. Fue desarrollada como 
    Trabajo Especial de Grado (TEG) para el IUT READIC-UNIR.<br><br>
    Su propósito es proporcionar a docentes y psicólogos institucionales una herramienta 
    de apoyo preventivo que permita identificar estudiantes en situación de vulnerabilidad 
    emocional antes de que el malestar escale a una crisis, respetando en todo momento 
    el anonimato y la dignidad del estudiante.
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")

    # ── Contexto venezolano ────────────────────────────
    st.subheader("🇻🇪 Contexto y relevancia")
    st.markdown("""
    <div style='background:rgba(255,170,68,0.08);border-left:4px solid #ffaa44;
    padding:20px;border-radius:10px;margin:10px 0;color:inherit;'>
    Venezuela enfrenta una situación de emergencia humanitaria compleja que impacta 
    directamente el bienestar psicológico de su población estudiantil. Con menos del 
    10% de la población accediendo a servicios de salud mental por barreras económicas, 
    y con docentes que no tienen herramientas formales para detectar malestar emocional 
    en el aula, existe una brecha crítica entre la necesidad y la atención disponible.<br><br>
    Esta plataforma fue diseñada específicamente para ese contexto: funciona de forma 
    local sin dependencia de servidores externos, no requiere internet para operar, 
    y utiliza lenguaje natural venezolano para el análisis de texto.
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")

    # ── Metodología ────────────────────────────────────
    st.subheader("🔬 Fundamentos metodológicos")

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("""
        <div style='background:rgba(255,255,255,0.05);padding:15px;border-radius:10px;'>
        <strong>Paradigma de investigación</strong><br><br>
        El proyecto integra tres paradigmas complementarios:<br>
        • <strong>Positivista</strong>: medición cuantitativa de indicadores emocionales<br>
        • <strong>Interpretativo</strong>: análisis cualitativo del texto libre<br>
        • <strong>Sociocrítico</strong>: intervención orientada al cambio social
        </div>
        """, unsafe_allow_html=True)

    with col2:
        st.markdown("""
        <div style='background:rgba(255,255,255,0.05);padding:15px;border-radius:10px;'>
        <strong>Metodología de diseño</strong><br><br>
        Se aplica <strong>Design Science Research (DSR)</strong>, que orienta la 
        construcción de artefactos tecnológicos como solución a problemas reales.<br><br>
        El método es <strong>mixto</strong>: combina datos cuantitativos de las 
        encuestas con datos cualitativos del análisis de texto libre.
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")

    # ── Stack tecnológico ──────────────────────────────
    st.subheader("⚙️ Stack tecnológico")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("""
        <div style='background:rgba(255,255,255,0.05);padding:15px;border-radius:10px;text-align:center;'>
        <strong>🐍 Backend</strong><br><br>
        Python 3<br>
        Streamlit<br>
        SQLite<br>
        python-dotenv
        </div>
        """, unsafe_allow_html=True)
    with col2:
        st.markdown("""
        <div style='background:rgba(255,255,255,0.05);padding:15px;border-radius:10px;text-align:center;'>
        <strong>🧠 Análisis</strong><br><br>
        VADER + Diccionario VE<br>
        scikit-learn (K-Means)<br>
        POMS reducido<br>
        Valence-Arousal
        </div>
        """, unsafe_allow_html=True)
    with col3:
        st.markdown("""
        <div style='background:rgba(255,255,255,0.05);padding:15px;border-radius:10px;text-align:center;'>
        <strong>📊 Visualización</strong><br><br>
        Plotly Express<br>
        Plotly Graph Objects<br>
        ReportLab (PDF)<br>
        OpenPyXL (Excel)
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")

    # ── Glosario ───────────────────────────────────────
    st.subheader("📚 Glosario técnico")

    with st.expander("Ver glosario de términos"):
        st.markdown("""
        **POMS (Profile of Mood States)**
        Instrumento psicométrico utilizado para evaluar diferentes estados afectivos.
        En esta plataforma se utiliza una versión reducida adaptada al contexto educativo,
        considerando las subescalas de Tensión, Fatiga y Vigor.
        ---

        **Valence-Arousal (VA)**
        Modelo bidimensional de las emociones propuesto por Russell (1980). 
        La Valencia (Valence) indica si el estado emocional es positivo o negativo 
        (escala -1 a +1). La Activación (Arousal) indica el nivel de energía o alerta 
        (escala 0 a 1). Juntos ubican cualquier emoción en un mapa de dos dimensiones.

        ---

        **K-Means Clustering**
        Algoritmo de aprendizaje automático no supervisado que agrupa estudiantes 
        con patrones emocionales similares sin necesidad de etiquetas previas. 
        Permite identificar subgrupos de riesgo dentro de una población estudiantil.

        ---

        **PCA (Análisis de Componentes Principales)**
        Técnica de reducción de dimensionalidad que permite visualizar en 2 dimensiones 
        datos que originalmente tienen 6 o más variables. Se usa para representar 
        gráficamente los clusters de estudiantes.

        ---

        **NLP (Procesamiento de Lenguaje Natural)**
        Rama de la inteligencia artificial que permite a los computadores analizar 
        texto escrito en lenguaje humano. En esta plataforma se usa para detectar 
        emociones y palabras de riesgo en el texto libre que escribe el estudiante.

        ---

        **Neurodiversidad**
        Concepto que reconoce la variación natural en el funcionamiento neurológico 
        humano. Los indicadores de neurodiversidad en esta plataforma son orientativos 
        y detectan posibles dificultades de atención, sensorialidad y procesamiento 
        cognitivo. No constituyen diagnóstico clínico.

        ---

        **Riesgo emocional preventivo**
        A diferencia del diagnóstico clínico, el riesgo preventivo identifica señales 
        tempranas de malestar antes de que alcancen niveles clínicamente significativos. 
        Esta plataforma opera exclusivamente en ese nivel preventivo y orientativo.
        """)

    st.markdown("---")

    # ── Declaración ética ──────────────────────────────
    st.subheader("⚖️ Declaración ética")
    st.markdown("""
    <div style='background:#2d2d00;border:1px solid #ffaa00;border-radius:8px;
    padding:15px;margin:10px 0;color:#ffd966;'>
    <strong>Principios éticos del sistema:</strong><br><br>
    • <strong>Protección de identidad:</strong> el sistema utiliza identificadores internos para gestionar
    los registros y evita exponer directamente datos personales en los análisis.<br>
    • <strong>Voluntariedad:</strong> la participación debe realizarse de manera libre e informada.<br>
    • <strong>No diagnóstico:</strong> el sistema es preventivo y orientativo, nunca clínico.<br>
    • <strong>Confidencialidad:</strong> los datos se gestionan mediante almacenamiento local y
    se aplican medidas orientadas a restringir su acceso.<br>
    • <strong>Beneficencia:</strong> el único propósito es el bienestar del estudiante.
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")

    # ── Autores ────────────────────────────────────────
    st.subheader("👥 Equipo de desarrollo")

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("""
        <div style='background:rgba(255,255,255,0.05);padding:20px;border-radius:10px;text-align:center;'>
        <strong>Eliezer Eduardo Chirinos Leal</strong><br><br>
        <strong>Alejandro José Covarrubias Cadenas</strong><br><br>
        <em>Informática</em><br>
        Sección C6-1
        <br><br>
        <br>
        </div>
        """, unsafe_allow_html=True)
    with col2:
        st.markdown("""
        <div style='background:rgba(255,255,255,0.05);padding:20px;border-radius:10px;text-align:center;'>
        <strong>Tutor Académico</strong><br><br>
        Ing. Luis Ugaz<br><br>
        <strong>Institución</strong><br>
        READIC-UNIR<br>
        </div>
        """, unsafe_allow_html=True)

# ================================================================
# LÓGICA PRINCIPAL DE LA APLICACIÓN
# ================================================================

# Verificar parámetros URL
qs = st.query_params

# Modo demo: salta landing, loader y autenticación docente
if qs.get("demo", "0") == "1":
    st.session_state.landing_done = True
    st.session_state.loader_shown = True
    st.session_state.docente_activo = True
    st.session_state.menu_docente = "Panel docente"
    st.session_state.rol_seleccionado = "Docente"
    st.query_params.clear()

# Landing normal
if qs.get("landing", ["0"])[0] == "1":
    st.session_state.landing_done = True

# Mostrar Landing Page si no se ha completado
if not st.session_state.landing_done:
    _logo_b64 = img_to_base64(LOGO_PATH)
    show_landing_page(_logo_b64)
    st.stop()

# Mostrar Loader si no se ha mostrado
if not st.session_state.loader_shown:
    _logo_b64 = img_to_base64(LOGO_PATH)
    frase = random.choice(FRASES_LOADER)
    show_loading_screen(_logo_b64, frase, seconds=LOADER_SECONDS)
    st.session_state.loader_shown = True
    time.sleep(LOADER_SECONDS)
    st.rerun()

# ================================================================
# BARRA LATERAL (SIDEBAR) - NAVEGACIÓN
# ================================================================

with st.sidebar:
    st.title("🧭 Navegación")
    
    # Selección de Rol
    rol_seleccionado = st.radio(
        "Selecciona tu rol:",
        ["Estudiante", "Docente", "Psicólogo"],
        key="rol_seleccionado"
    )

    # 🔥 Sincronizar con router
    st.session_state.route["rol"] = rol_seleccionado
    
    # Navegación para Estudiante
    if rol_seleccionado == "Estudiante":
        st.subheader("👤 Área de Estudiante")
        
        if st.button("📝 Registrar nueva encuesta"):
            set_route("registro")
            st.rerun()
        
        if st.button("📊 Ver mi historial", use_container_width=True):
            set_route("historial")
            st.rerun()
        
        if st.button("ℹ️ Información sobre la plataforma", use_container_width=True):
            set_route("info")
            st.rerun()
        
        if st.button("📖 Acerca del proyecto", use_container_width=True):
            set_route("acerca")
            st.rerun()

    elif rol_seleccionado == "Docente":
        st.subheader("👨‍🏫 Área de Docente")

        if not st.session_state.get('docente_activo'):
            clave = st.text_input("🔑 Clave de acceso docente:", type="password")
            if st.button("🔓 Acceder como docente", use_container_width=True):
                clave_docente = os.getenv("CLAVE_DOCENTE")

            if not clave_docente:
                st.error("El acceso docente no está configurado correctamente.")
            else:
                if clave == clave_docente:
                    st.session_state.docente_activo = True
                    st.success("Acceso concedido")
                    st.rerun()
                else:
                    st.error("Clave incorrecta")

        else:
            if st.button("📈 Panel docente general", use_container_width=True):
                set_route("panel")
                st.rerun()

            if st.button("🧠 Clustering de riesgo", use_container_width=True):
                set_route("clustering")
                st.rerun()

            if st.button("📊 Dashboard histórico", use_container_width=True):
                set_route("dashboard_hist")
                st.rerun()

            if st.button("👨‍🏫 Dashboard profesional", use_container_width=True):
                set_route("dashboard_prof")
                st.rerun()

            if st.button("🚨 Alertas inteligentes", use_container_width=True):
                set_route("alertas")
                st.rerun()

            if st.button("📁 Exportar datos", use_container_width=True):
                set_route("export")
                st.rerun()

            if st.button("📖 Acerca del proyecto", use_container_width=True):
                set_route("acerca")
                st.rerun()

            st.markdown("---")
            # 🔥 NUEVO: Botón de cierre de sesión para Docente
            if st.button("🔒 Cerrar sesión", use_container_width=True):
                logout()
                st.rerun()

    elif rol_seleccionado == "Psicólogo":
        st.subheader("🧠 Área de Psicólogo")

        if not st.session_state.get('psicologo_activo'):
            clave_p = st.text_input("🔑 Clave de acceso:", type="password")
            if st.button("🔓 Acceder como psicólogo", use_container_width=True):
                clave_psicologo = os.getenv("CLAVE_PSICOLOGO")

            if not clave_psicologo:
                st.error("El acceso de psicología no está configurado correctamente.")
            else:
                if clave_p == clave_psicologo:
                    st.session_state.psicologo_activo = True
                    st.success("Acceso concedido")
                    st.rerun()
                else:
                    st.error("Clave incorrecta")

        else:
            if st.button("👤 Historial individual", use_container_width=True):
                set_route("historial")
                st.rerun()

            if st.button("🚨 Casos prioritarios", use_container_width=True):
                set_route("casos")
                st.rerun()

            if st.button("📈 Dashboard histórico", use_container_width=True):
                set_route("dashboard")
                st.rerun()

            if st.button("📖 Acerca del proyecto", use_container_width=True):
                set_route("acerca")
                st.rerun()

            st.markdown("---")
            # 🔥 NUEVO: Botón de cierre de sesión para Psicólogo
            if st.button("🔒 Cerrar sesión", use_container_width=True):
                logout()
                st.rerun()

# ================================================================
# SERVICIO PRINCIPAL DE PROCESAMIENTO DE ENCUESTA
# ================================================================
def process_survey_service(nivel, edad, respuestas):
    # 1. NLP
    texto = respuestas.get("texto", "")
    polarity, subjectivity, neg_count = analyze_text_advanced(texto)

    # 2. Procesamiento principal
    puntaje, riesgo, valence, arousal, nd_score = process_results_by_level(
        nivel, respuestas, (polarity, subjectivity, neg_count)
    )

    # 3. POMS si aplica
    poms_scores = {
        "tension": 0.0,
        "depresion": 0.0,
        "fatiga": 0.0,
        "vigor": 0.0
    }
    if nivel == "Universidad":
        poms_respuestas = {
            "tension": respuestas.get("poms_tension", 3),
            "depresion": respuestas.get("poms_depresion", 3),
            "fatiga": respuestas.get("poms_fatiga", 3),
            "vigor": respuestas.get("poms_vigor", 3),
        }
        poms_scores = score_poms(poms_respuestas)

    # 4. Perfil
    perfil = classify_profile(puntaje, polarity, subjectivity, poms_scores, neg_count)

    # 5. detalle
    detalle = {
    "meta": {
        "nivel": nivel,
        "edad": edad
    },

    "resultado": {
        "puntaje": puntaje,
        "riesgo": riesgo,
        "perfil": perfil
    },

    "emocional": {
        "polarity": polarity,
        "subjectivity": subjectivity,
        "neg_words": neg_count
    },

    "va": {
        "valence": valence,
        "arousal": arousal
    },

    "poms": poms_scores,

    "neurodiv": {
        "nd_score": nd_score
    },

    "texto": texto
   }

    # 6. DATA CONTRACT (PRIMERO)
    result = {
        "uid": None,  # temporal
        "nivel": nivel,
        "edad": edad,

        "riesgo": riesgo,
        "puntaje": puntaje,
        "perfil": perfil,

        "emocional": {
            "polarity": polarity,
            "subjectivity": subjectivity,
            "neg_words": neg_count
        },

        "va": {
            "valence": valence,
            "arousal": arousal
        },

        "cognitivo": {
            "nd_score": nd_score
        },

        "poms": poms_scores,

        "texto": texto[:100]
    }

    # 7. DB
    uid = save_user("estudiante", edad, nivel)
    eid = save_survey(uid, respuestas)

    result["uid"] = uid   # 🔥 IMPORTANTE

    save_result(eid, riesgo, puntaje, detalle)

    return result


# ================================================================
# CONTENIDO PRINCIPAL SEGÚN SELECCIÓN
# ================================================================

# Área de Estudiante
if rol_seleccionado == "Estudiante":
    if st.session_state.menu_estudiante == "Registrar encuesta":
        # ===== PANTALLA DE CONSENTIMIENTO INFORMADO =====
        if not st.session_state.consentimiento:
            st.title("📝 Consentimiento Informado")
            st.markdown("""
            ### Antes de comenzar, por favor lee atentamente:
            
            **Propósito:** Esta plataforma tiene como objetivo evaluar tu bienestar emocional 
            y cognitivo para detectar posibles riesgos de manera temprana.
            
            **Confidencialidad:** 
            - Tus respuestas son **anónimas** y **confidenciales**.
            - Solo el personal autorizado (docentes/psicólogos) tendrá acceso a los datos 
              agregados, nunca a tu identidad individual.
            - Los datos se almacenan de forma segura en una base de datos local.
            
            **Uso de los datos:**
            - Para análisis estadísticos grupales.
            - Para identificar patrones de riesgo que permitan mejorar los programas de apoyo.
            - Nunca para evaluación académica o personal.
            
            **Tu participación es:**
            - **Voluntaria**: puedes dejar de responder en cualquier momento.
            - **Gratuita**: no hay costo alguno.
            - **Reversible**: puedes solicitar la eliminación de tus datos.
            
            ---
            
            **¿Aceptas participar en esta evaluación?**
            """)
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("✅ Sí, acepto participar", use_container_width=True):
                    st.session_state.consentimiento = True
                    st.rerun()
            with col2:
                if st.button("❌ No, prefiero no participar", use_container_width=True):
                    st.info("Gracias por tu consideración. Si cambias de opinión, puedes regresar en cualquier momento.")
                    st.stop()
            
            st.markdown("---")
            st.caption("Esta plataforma cumple con los estándares éticos de investigación con seres humanos.")
        
        # ===== FORMULARIO DE REGISTRO =====
        else:
            st.title("📝 Registro de Encuesta")
            
            # Selector de nivel FUERA del formulario para que recargue las preguntas
            col1, col2 = st.columns(2)
            with col1:
                edad = st.number_input("Edad", min_value=5, max_value=80, value=15, step=1)
            with col2:
                nivel = st.selectbox(
                    "Nivel educativo",
                        ["Universidad"],
                index=0,
                key="nivel_usuario"
                )

            with st.form("registro_form"):
                st.subheader("Encuesta de bienestar")
    
                questions = get_questions_by_level(nivel)
                respuestas = render_questions_by_level(questions)
                
                submitted = st.form_submit_button("📤 Enviar encuesta", use_container_width=True)
                
                if submitted:
                    try:
                        with st.spinner("Analizando respuestas..."):
                            result = process_survey_service(nivel, edad, respuestas)

                        # SOLO si existe result
                        if not result:
                            st.error("Error: resultado vacío")
                            st.stop()

                        st.session_state.last_report_data = result
                        st.session_state.uid = result.get("uid")

                        set_route("resultados")

                        st.success("✅ Encuesta enviada correctamente")
                        st.balloons()
                        st.stop()

                    except Exception as e:
                        st.error(f"Error al guardar los datos: {str(e)}")     
                            
        
    
    elif st.session_state.menu_estudiante == "Ver historial":
        st.title("📊 Mi Historial de Evaluaciones")
        st.markdown("Aquí puedes ver la evolución de tu bienestar emocional a lo largo del tiempo.")

        uid = st.session_state.get("uid")

        if not uid:
            st.info("Realiza tu primera evaluación para ver tu historial aquí.")
            if st.button("📝 Comenzar evaluación", key="btn_hist_nueva"):
                st.session_state.consentimiento = False
                set_route("registro")
                st.rerun()
        else:
            df_hist = fetch_historial_usuario(uid, include_respuestas_y_nivel=False)

            if df_hist.empty:
                st.info("Aún no tienes evaluaciones registradas.")
                if st.button("📝 Hacer primera evaluación", key="btn_hist_empty"):
                    st.session_state.consentimiento = False
                    set_route("registro")
                    st.rerun()
            else:
                # Procesar datos
                df_hist["data"] = df_hist["detalle"].apply(safe_json_load)

                df_hist["fecha_dt"] = pd.to_datetime(df_hist["fecha"], errors="coerce")
                df_hist = df_hist.dropna(subset=["fecha_dt"])

                df_hist["puntaje"] = df_hist["data"].apply(lambda x: x.get("resultado", {}).get("puntaje"))
                df_hist["perfil"] = df_hist["data"].apply(lambda x: x.get("resultado", {}).get("perfil"))
                df_hist["riesgo"] = df_hist["data"].apply(lambda x: x.get("resultado", {}).get("riesgo"))
                df_hist["emocional"] = df_hist["data"].apply(lambda x: x.get("emocional", {}))
                df_hist["va"] = df_hist["data"].apply(lambda x: x.get("va", {}))
                df_hist["cognitivo"] = df_hist["data"].apply(lambda x: x.get("cognitivo", {}))
                df_hist["poms"] = df_hist["data"].apply(lambda x: x.get("poms", {}))

                # ── Métricas resumen ──────────────────────────────
                st.subheader("📈 Resumen")
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Total evaluaciones", len(df_hist))
                with col2:
                    ultimo_riesgo = df_hist["riesgo"].iloc[0]
                    color_map = {
                        "Bajo": "🟢",
                        "Medio": "🟡",
                        "Alto": "🔴"
                    }
                    st.metric("Último riesgo", 
                    f"{color_map.get(ultimo_riesgo, '⚪')} {ultimo_riesgo}")
                with col3:
                    puntaje_prom = df_hist["puntaje"].mean()
                    st.metric("Puntaje promedio", f"{puntaje_prom:.2f}")

                st.markdown("---")

                # ── Gráfico de evolución ──────────────────────────
                st.subheader("📊 Evolución del Riesgo")
                fig_hist = px.line(
                    df_hist.sort_values("fecha_dt"),
                    x="fecha_dt",
                    y="puntaje",
                    markers=True,
                    title="Evolución de tu puntaje de bienestar",
                    labels={"fecha_dt": "Fecha", "puntaje": "Puntaje (0-1)"},
                    color_discrete_sequence=["#4fc3f7"]
                )
                fig_hist.add_hline(
                    y=0.65, line_dash="dash", 
                    line_color="red", 
                    annotation_text="Límite Alto"
                )
                fig_hist.add_hline(
                    y=0.40, line_dash="dash", 
                    line_color="orange",
                    annotation_text="Límite Medio"
                )
                fig_hist.update_layout(
                    plot_bgcolor="rgba(0,0,0,0)",
                    paper_bgcolor="rgba(0,0,0,0)"
                )
                st.plotly_chart(fig_hist, use_container_width=True)

                st.markdown("---")

                # ── Tabla de historial ────────────────────────────
                st.subheader("📋 Detalle de Evaluaciones")
                df_tabla = df_hist[["fecha", "puntaje", "riesgo", "perfil"]].copy()
                df_tabla.columns = ["Fecha", "Puntaje", "Riesgo", "Perfil"]
                df_tabla["Puntaje"] = df_tabla["Puntaje"].round(3)

                def color_riesgo(val):
                    colores = {
                        "Bajo": "background-color: rgba(46,204,113,0.2)",
                        "Medio": "background-color: rgba(241,196,15,0.2)",
                        "Alto": "background-color: rgba(231,76,60,0.2)"
                    }
                    return colores.get(val, "")

                st.dataframe(
                    df_tabla.style.applymap(color_riesgo, subset=["Riesgo"]),
                    use_container_width=True,
                    hide_index=True
                )

                st.markdown("---")
                st.caption("💡 Cada evaluación es un punto de datos. La tendencia a lo largo "
                      "del tiempo es más importante que cualquier resultado individual.")
    
    elif st.session_state.menu_estudiante == "Resultados":

        
        # Bloque de resultados
        st.title("✨ Reporte de Evaluación")
        
        # Recuperar datos del reporte guardados en la sesión
        data = st.session_state.get('last_report_data', {})
        
        if not data:
            st.warning("No se encontraron datos de la última encuesta. Por favor, realiza una nueva evaluación.")
            if st.button("⬅️ Volver a Encuesta", key="btn_volver_encuesta"):
                st.session_state.menu_estudiante = "Registrar encuesta"
                st.rerun()
            st.stop()
            
        uid = data["uid"]

        show_single_report(
            riesgo=data["riesgo"],
            perfil=data["perfil"],
            resultado=data
        )
        
        # 2. Generar alertas inteligentes
        alerts = generate_smart_alerts(uid)
        if alerts:
            st.subheader("🚨 Alertas de Seguimiento")
            for alert in alerts:
                if "🔴" in alert:
                    st.error(alert)
                elif "🟡" in alert:
                    st.warning(alert)
                else:
                    st.success(alert)
            
        # 3. Opciones Post-Envío (REUBICADAS AQUÍ)
        st.markdown("---")
        st.subheader("🎯 ¿Qué te gustaría hacer ahora?")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button(
                "📊 Ver mi historial de evaluaciones",
                use_container_width=True,
                key="btn_historial_res"
            ):
                if "last_report_data" in st.session_state:
                    del st.session_state.last_report_data

                set_route("historial")
                st.rerun()
        with col2:
            if st.button(
                "📝 Comenzar nueva evaluación",
                use_container_width=True,
                key="btn_nueva_res"
            ):
                st.session_state.consentimiento = False

                if "last_report_data" in st.session_state:
                    del st.session_state.last_report_data

                set_route("registro")
                st.rerun()

    elif st.session_state.menu_estudiante == "Información":
        st.title("ℹ️ Información sobre la plataforma")
        st.markdown("""
        ## Plataforma de Detección Temprana Emocional
        
        ### ¿Qué es?
        Esta plataforma tiene como objetivo evaluar y monitorear el bienestar emocional 
        y cognitivo de estudiantes de diferentes niveles educativos.
        
        ### ¿Cómo funciona?
        1. **Registro anónimo**: No necesitas proporcionar tu nombre
        2. **Encuesta adaptativa**: Las preguntas se ajustan a tu nivel educativo
        3. **Análisis automático**: El sistema analiza tus respuestas en tiempo real
        4. **Feedback inmediato**: Recibes un reporte personalizado
        
        ### ¿Qué mide?
        - **Estado emocional**: ánimo, motivación, estrés
        - **Factores cognitivos**: atención, fatiga mental
        - **Indicadores de riesgo**: detección temprana de problemas
        
        ### Confidencialidad
        - Tus respuestas son completamente anónimas
        - Los datos se usan solo para análisis estadísticos
        - No afectan tu evaluación académica
        
        ### Equipo responsable
        Esta plataforma ha sido desarrollada por un equipo multidisciplinario 
        de psicólogos, educadores y desarrolladores.
        
        ---
        
        **Para preguntas o soporte:** eliezer.05le4l@gmail.com
        """)


    elif st.session_state.menu_estudiante == "Acerca":
        show_acerca()

# Área de Docente
elif rol_seleccionado == "Docente":
    if not st.session_state.get('docente_activo'):
        st.title("🔒 Acceso Docente")
        st.info("Por favor, ingresa la clave de acceso en la barra lateral para acceder al panel docente.")
        
    else:
        if st.session_state.menu_docente == "Panel docente":
            st.title("👨‍🏫 Panel Docente")
            st.markdown("Bienvenido al panel de administración docente.")
            
            # ── Métricas generales ────────────────────────────
            try:
                total_usuarios, total_encuestas, total_resultados = fetch_counts_resumen()
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Total Usuarios", total_usuarios)
                with col2:
                    st.metric("Total Encuestas", total_encuestas)
                with col3:
                    st.metric("Total Resultados", total_resultados)
            except Exception as e:
                st.error(f"Error al obtener estadísticas: {e}")

            # ── Semáforo de situación actual ──────────────────
            st.markdown("---")
            st.subheader("🚦 Situación General del Grupo")

            try:
                df_semaforo = fetch_riesgo_counts_por_resultado()
            except Exception:
                df_semaforo = pd.DataFrame()

            total = int(df_semaforo["cantidad"].sum()) if not df_semaforo.empty else 0
            alto  = int(df_semaforo[df_semaforo["riesgo"] == "Alto"]["cantidad"].sum()) if not df_semaforo.empty else 0
            medio = int(df_semaforo[df_semaforo["riesgo"] == "Medio"]["cantidad"].sum()) if not df_semaforo.empty else 0
            bajo  = int(df_semaforo[df_semaforo["riesgo"] == "Bajo"]["cantidad"].sum()) if not df_semaforo.empty else 0

            porcentaje_alto  = (alto / total) if total > 0 else 0
            porcentaje_medio = (medio / total) if total > 0 else 0

            if total == 0:
                st.markdown("""
                <div style='padding:15px;border-radius:8px;background:#1a3a1a;border:1px solid #44cc44;color:#aaffaa;'>
                ℹ️ <strong>Sin datos:</strong> No hay evaluaciones registradas aún.
                </div>
                """, unsafe_allow_html=True)
            elif porcentaje_alto >= 0.30:
                st.markdown(f"""
                <div style='padding:15px;border-radius:8px;background:#3a0000;border:1px solid #ff4444;color:#ffaaaa;'>
                🔴 <strong>ATENCIÓN URGENTE:</strong> {alto} estudiante(s) en riesgo alto ({porcentaje_alto*100:.0f}% del total). Se recomienda intervención inmediata.
                </div>
                """, unsafe_allow_html=True)
            elif porcentaje_medio >= 0.40 or alto >= 1:
                st.markdown(f"""
                <div style='padding:15px;border-radius:8px;background:#2d2d00;border:1px solid #ffaa00;color:#ffd966;'>
                🟡 <strong>SEGUIMIENTO RECOMENDADO:</strong> {alto} en riesgo alto y {medio} en riesgo medio. Revisar casos prioritarios.
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div style='padding:15px;border-radius:8px;background:#1a3a1a;border:1px solid #44cc44;color:#aaffaa;'>
                🟢 <strong>SITUACIÓN ESTABLE:</strong> La mayoría del grupo ({bajo} estudiantes) presenta riesgo bajo.
                </div>
                """, unsafe_allow_html=True)

            st.markdown("<br>", unsafe_allow_html=True)
            col_s1, col_s2, col_s3 = st.columns(3)

            col_s1, col_s2, col_s3 = st.columns(3)
            with col_s1:
                st.metric("🔴 Riesgo Alto", alto)
            with col_s2:
                st.metric("🟡 Riesgo Medio", medio)
            with col_s3:
                st.metric("🟢 Riesgo Bajo", bajo)

            # ── Opciones disponibles ──────────────────────────
            st.markdown("---")
            st.subheader("Opciones disponibles")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("📊 Ver Dashboard Profesional", use_container_width=True):
                    set_route("dashboard_prof")
                    st.rerun()
                if st.button("📈 Ver Dashboard Histórico", use_container_width=True):
                    set_route("dashboard_hist")
                    st.rerun()
            with col2:
                if st.button("🧠 Análisis de Clustering", use_container_width=True):
                    set_route("clustering")
                    st.rerun()
                if st.button("🚨 Ver Alertas", use_container_width=True):
                    set_route("alertas")
                    st.rerun()
        
        elif st.session_state.menu_docente == "Clustering":
            show_panel_docente()
        
        elif st.session_state.menu_docente == "Dashboard histórico":
            show_dashboard_historico()
        
        elif st.session_state.menu_docente == "Dashboard profesional":
            show_dashboard_profesional()
        
        elif st.session_state.menu_docente == "Alertas inteligentes":
            show_alertas_inteligentes()
        
        elif st.session_state.menu_docente == "Exportar datos":
            st.title("📁 Exportar Datos")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if st.button("📊 Exportar CSV General", use_container_width=True):
                    df = fetch_resultados_all()
                    csv_bytes = df_to_csv_bytes(df)
                    st.download_button(
                        label="📥 Descargar CSV",
                        data=csv_bytes,
                        file_name="resultados_general.csv",
                        mime="text/csv",
                        use_container_width=True
                    )
            
            with col2:
                if st.button("📦 Exportar ZIP Completo", use_container_width=True):
                    zip_bytes = export_all_tables_zip_bytes()
                    st.download_button(
                        label="📥 Descargar ZIP",
                        data=zip_bytes,
                        file_name="datos_completos.zip",
                        mime="application/zip",
                        use_container_width=True
                    )
            
            with col3:
                if st.button("📄 Exportar PDF Profesional", use_container_width=True):
                    try:
                        pdf_bytes = generar_pdf_profesional_bytes()
                        st.download_button(
                            label="📥 Descargar PDF",
                            data=pdf_bytes,
                            file_name="reporte_profesional.pdf",
                            mime="application/pdf",
                            use_container_width=True
                        )
                    except Exception as e:
                        st.error(f"Error al generar PDF: {e}")
            
            st.markdown("---")
            st.subheader("📈 Exportar Excel Completo")
            
            if st.button("📊 Generar Reporte Excel Completo", use_container_width=True):
                try:
                    excel_bytes = generar_excel_completo_bytes()
                    st.download_button(
                        label="📥 Descargar Excel",
                        data=excel_bytes,
                        file_name="reporte_completo.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        use_container_width=True
                    )
                except Exception as e:
                    st.error(f"Error al generar Excel: {e}")

        elif st.session_state.menu_docente == "Acerca":
            show_acerca()
# ================================================================
# ÁREA DE PSICÓLOGO
# ================================================================
elif rol_seleccionado == "Psicólogo":
    if not st.session_state.get('psicologo_activo'):
        st.title("🔒 Acceso Psicólogo")
        st.info("Por favor, ingresa la clave de acceso en la barra lateral.")

    else:
        if st.session_state.menu_psicologo == "Historial individual":
            st.title("👤 Historial Individual de Estudiante")
            st.markdown("Consulta el historial completo de cualquier estudiante por su ID.")

            usuarios_disponibles = fetch_usuarios_ids_ordered()

            if usuarios_disponibles.empty:
                st.info("No hay estudiantes registrados aún.")
            else:
                ids = usuarios_disponibles["id"].tolist()
                uid_sel = st.selectbox("Seleccionar ID de estudiante:", ids)

                df_ind = fetch_historial_usuario(
                    uid_sel,
                    include_respuestas_y_nivel=True
                )

                if df_ind.empty:
                    st.info("Este estudiante no tiene evaluaciones registradas.")
                else:
                    df_ind["fecha_dt"] = pd.to_datetime(
                        df_ind["fecha"],
                        errors="coerce"
                    )


                    df_ind["perfil"] = df_ind["data"].apply(lambda x: x.get("resultado", {}).get("perfil") or x.get("Perfil", "N/A"))
                    df_ind["riesgo"] = df_ind["data"].apply(lambda x: x.get("resultado", {}).get("riesgo"))
                    df_ind["puntaje"] = df_ind["data"].apply(lambda x: x.get("resultado", {}).get("puntaje"))

                    df_ind["poms"] = df_ind["data"].apply(lambda x: x.get("poms", {}))
                    

                    # ── Resumen del estudiante ──────────────────
                    st.subheader("📋 Resumen del Estudiante")
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("ID", uid_sel)
                    with col2:
                        st.metric("Nivel", df_ind["nivel"].iloc[0])
                    with col3:
                        st.metric("Evaluaciones", len(df_ind))
                    with col4:
                        ultimo = df_ind["riesgo"].iloc[0]
                        emoji = {"Alto": "🔴", "Medio": "🟠", "Bajo": "🟢"}.get(ultimo, "⚪")
                        st.metric("Último riesgo", f"{emoji} {ultimo}")

                    st.markdown("---")

                    # ── Evolución del riesgo ────────────────────
                    st.subheader("📈 Evolución del Riesgo")
                    fig_ev = px.line(
                        df_ind.sort_values("fecha_dt"),
                        x="fecha_dt", y="puntaje",
                        markers=True,
                        labels={"fecha_dt": "Fecha", "puntaje": "Puntaje (0-1)"},
                        color_discrete_sequence=["#4fc3f7"]
                    )
                    fig_ev.add_hline(y=0.65, line_dash="dash", line_color="red", annotation_text="Alto")
                    fig_ev.add_hline(y=0.40, line_dash="dash", line_color="orange", annotation_text="Medio")
                    fig_ev.update_layout(plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)")
                    st.plotly_chart(fig_ev, use_container_width=True)

                    st.markdown("---")

                    # ── Evolución POMS ──────────────────────────
                    st.subheader("🧠 Evolución de Estados Afectivos (POMS)")
                    fig_poms = go.Figure()
                    df_sorted = df_ind.sort_values("fecha_dt")
                    fig_poms.add_trace(go.Scatter(
                        x=df_sorted["fecha_dt"],
                        y=df_sorted["poms"].apply(lambda x: x.get("tension", 0)),
                        name="Tensión",
                        line=dict(color="red", width=2)
                    ))
                    fig_poms.add_trace(go.Scatter(
                        x=df_sorted["fecha_dt"],
                        y=df_sorted["poms"].apply(lambda x: x.get("fatigue", 0)),
                        name="Fatiga",
                        line=dict(color="orange", width=2)
                    ))
                    fig_poms.add_trace(go.Scatter(
                        x=df_sorted["fecha_dt"],
                        y=df_sorted["poms"].apply(lambda x: x.get("vigor", 0)),
                        name="Vigor",
                        line=dict(color="green", width=2)
                    ))
                    fig_poms.update_layout(
                        xaxis_title="Fecha",
                        yaxis_title="Intensidad (0-1)",
                        hovermode="x unified",
                        plot_bgcolor="rgba(0,0,0,0)",
                        paper_bgcolor="rgba(0,0,0,0)"
                    )
                    st.plotly_chart(fig_poms, use_container_width=True)

                    st.markdown("---")

                    # ── Textos libres ───────────────────────────
                    st.subheader("📝 Textos Libres por Sesión")
                    st.caption("⚠️ Información sensible — uso exclusivo del psicólogo orientador.")
                    for _, row in df_ind.iterrows():
                        texto = row["texto_libre"]

                        if texto and texto.strip():
                            with st.expander(f"Sesión: {row['fecha']} — Riesgo: {row.get('riesgo', 'N/A')}"):
                                st.markdown(f"""
                                <div style='background:#1a1a2e;padding:15px;border-radius:8px;
                                border-left:4px solid #4fc3f7;color:#e0e0e0;font-style:italic;'>
                                "{texto}"
                                </div>
                                """, unsafe_allow_html=True)

                                puntaje = row.get("puntaje")
                                perfil = row.get("perfil", "N/A")

                                if puntaje is not None:
                                    puntaje_str = f"{puntaje:.3f}"
                                else:
                                    puntaje_str = "N/A"

                                st.caption(f"Perfil: {perfil} | Puntaje: {puntaje_str}")

                    st.markdown("---")

                    # ── Exportar PDF individual ─────────────────
                    st.subheader("📄 Exportar Reporte Individual")
                    if st.button("Generar PDF de este estudiante", use_container_width=True):
                        try:
                            pdf_bytes = generar_pdf_historial_bytes(
                                f"Estudiante ID {uid_sel}",
                                df_ind[["fecha", "puntaje", "riesgo", "perfil"]].rename(
                                    columns={"fecha": "Fecha", "puntaje": "Puntaje",
                                             "riesgo": "Riesgo", "perfil": "Perfil"})
                            )
                            st.download_button(
                                label="📥 Descargar PDF",
                                data=pdf_bytes,
                                file_name=f"reporte_estudiante_{uid_sel}.pdf",
                                mime="application/pdf",
                                use_container_width=True
                            )
                        except Exception as e:
                            st.error(f"Error al generar PDF: {e}")

        elif st.session_state.menu_psicologo == "Casos prioritarios":
            st.title("🚨 Casos Prioritarios")
            st.markdown("Estudiantes con riesgo alto que requieren seguimiento y orientación profesional.")

            df_prior = fetch_casos_prioritarios()

            if df_prior.empty:
                st.success("🟢 No hay casos en riesgo alto actualmente.")
            else:
                df_prior["detalle_json"]    = df_prior["detalle"].apply(safe_json_load)
                df_prior["respuestas_json"] = df_prior["respuestas"].apply(safe_json_load)
                df_prior["perfil"]          = df_prior["detalle_json"].apply(lambda x: x.get("resultado", {}).get("perfil", "N/A"))
                df_prior["texto_libre"]     = df_prior["respuestas_json"].apply(lambda x: x.get("texto", ""))

                st.markdown(f"**{len(df_prior)}** casos en riesgo alto detectados.")

                for _, caso in df_prior.iterrows():
                    with st.expander(
                        f"🔴 ID {caso['usuario_id']} | {caso['nivel']} | Puntaje: {caso['puntaje']:.3f} | {caso['fecha']}"):
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Puntaje", f"{caso['puntaje']:.3f}")
                        with col2:
                            st.metric("Perfil", caso["perfil"])
                        with col3:
                            st.metric("Nivel", caso["nivel"])

                        if caso["texto_libre"] and caso["texto_libre"].strip():
                            st.markdown("**Texto libre del estudiante:**")
                            st.markdown(f"""
                            <div style='background:#1a1a2e;padding:12px;border-radius:8px;
                            border-left:4px solid #ff4444;color:#e0e0e0;font-style:italic;'>
                            "{caso['texto_libre']}"
                            </div>
                            """, unsafe_allow_html=True)
                        else:
                            st.caption("El estudiante no escribió texto libre en esta sesión.")

        elif st.session_state.menu_psicologo == "Dashboard histórico":
            show_dashboard_historico()

        elif st.session_state.menu_psicologo == "Acerca":
            show_acerca()
# ================================================================
# PIE DE PÁGINA
# ================================================================
st.markdown("---")
st.caption("Todos los derechos reservados • Versión 4.0 • © 2026")